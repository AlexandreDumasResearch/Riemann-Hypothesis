COMPLETE LATEX SOURCE AND BIBLIOGRAPHY

Signed Prime Correlations and Theta Continuation for the Riemann Xi Function
Alexandre Dumas | ORCID 0009-0003-1695-0086 | 13 October 2026

All manuscript text, bibliography and required figure PDFs are supplied.
From source/ run:

  latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex

Alternatively run pdflatex, bibtex main, then pdflatex twice.
Requires standard TeX Live AMS, natbib, Latin Modern, microtype, hyperref,
geometry, enumitem, booktabs, longtable, caption and fancyhdr packages.
The result is source/main.pdf. No Python is needed for this build.
The separate complete reproducibility archive contains code and exact data.
Verify this snapshot with sha256sum -c SHA256SUMS.txt.
