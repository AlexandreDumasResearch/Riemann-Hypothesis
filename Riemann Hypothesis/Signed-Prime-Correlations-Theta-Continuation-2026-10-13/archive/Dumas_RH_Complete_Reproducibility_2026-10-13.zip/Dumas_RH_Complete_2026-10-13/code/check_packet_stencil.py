#!/usr/bin/env python3
"""Exact finite-difference checks plus NONVALIDATED high-precision diagnostics."""
from fractions import Fraction
import json
from math import comb
from pathlib import Path
import mpmath as mp

mp.mp.dps=220
out={"status":"Exact rational moment checks; remaining quantities are nonvalidated mpmath diagnostics, not numerical certificates.","exact_moment_checks":[],"fixed_order_diagnostics":[],"growing_order_diagnostics":[],"alternate_measure_diagnostics":[]}
for n in (3,7,19):
    for k in range(1,9):
        for r in range(k):
            s=sum(Fraction((-1)**(k-j)*comb(k,j),2**k)*Fraction(4*n*n+j,n)**r for j in range(k+1))
            assert s==0
        out["exact_moment_checks"].append({"n":n,"k":k,"all_lower_moments_exactly_zero":True})

def kernel(n,x):
    # Independently evaluate the manuscript's Laguerre polynomial stencil.
    u=3*x
    L0=mp.mpf(1); L1=1-u
    ls=[mp.mpf(1),u/2]
    prev,curr=L0,L1
    for j in range(2,2*n):
        nxt=((2*j-1-u)*curr-(j-1)*prev)/j
        ls.append(((-1)**j)*(nxt-curr)/2)
        prev,curr=curr,nxt
    z=(132*ls[0]-160*ls[1]+32*ls[2]
       +16*ls[2*n-5]-80*ls[2*n-4]+132*ls[2*n-3]-80*ls[2*n-2]+16*ls[2*n-1])
    return mp.mpf(32)/2187*mp.exp(-x)*z

def response(n,k):
    return mp.fsum((-1)**(k-j)*mp.binomial(k,j)*kernel(n,mp.mpf(4*n)+mp.mpf(j)/n) for j in range(k+1))/2**k

r0=2-mp.sqrt(3); d0=(mp.sqrt(3)-1)/2
H=2*mp.log(2+mp.sqrt(3))-2*(mp.sqrt(3)-1)
A=lambda z:4*(1-2*z)**2*(2-z)**2
sigma=2/mp.sqrt(3)
pref=16*r0*A(r0)/(2187*mp.sqrt(2*mp.pi*sigma))
out["constants"]={"H4":str(H),"r0":str(r0),"delta0":str(d0)}
for n in (30,60,120,240):
    for k in (1,3):
        val=response(n,k)
        leading=(-1)**k*pref*(d0/2)**k*mp.mpf(n)**(-k-mp.mpf('.5'))*mp.exp(n*H)
        out["fixed_order_diagnostics"].append({"n":n,"k":k,"sign":int(mp.sign(val)),"ratio_to_asymptotic":mp.nstr(val/leading,25),"log_abs_over_n":mp.nstr(mp.log(abs(val))/n,25)})
for n in (60,120,240):
    kap=mp.mpf('.5')
    k=int(mp.floor(kap*n/mp.log(n)))
    val=response(n,k)
    pred=n*H-k*mp.log(2*n)+k*mp.log(d0)
    out["growing_order_diagnostics"].append({"n":n,"k":k,"sign":int(mp.sign(val)),"correct_sign":int(mp.sign(val))==(-1)**k,"log_abs_over_n":mp.nstr(mp.log(abs(val))/n,25),"leading_log_over_n":mp.nstr(pred/n,25),"error_in_log":mp.nstr(mp.log(abs(val))-pred,25)})
for n in (30,60,120,240):
    k=3
    val=mp.fsum((-1)**(k-j)*mp.binomial(k,j)*mp.exp(mp.mpf(j)/n)*kernel(n,mp.mpf(4*n)+mp.mpf(j)/n) for j in range(k+1))/2**k
    leading=pref*((1-d0)/2)**k*mp.mpf(n)**(-k-mp.mpf('.5'))*mp.exp(n*H)
    out["alternate_measure_diagnostics"].append({"n":n,"k":k,"sign":int(mp.sign(val)),"ratio_to_asymptotic":mp.nstr(val/leading,25)})
path=Path(__file__).resolve().parents[1]/'results'/('packet_stencil_diagnostics.json')
path.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({"exact_checks":len(out['exact_moment_checks']),"fixed_order":out['fixed_order_diagnostics'],"growing_order":out['growing_order_diagnostics']},indent=2))
