"""Exact finite checks for the divisor-logarithm quarter-surplus theorem.

No prime asymptotic or sharp-limit assertion is inferred from these checks.
Only the Python standard library is required.
"""
from fractions import Fraction as F
from pathlib import Path
import json

N = 4096
nu = [F(0) for _ in range(N+1)]
nu[1] = F(1)
power = [0]*(N+1)
power[1] = 1
for j in range(1, N.bit_length()):
    nxt = [0]*(N+1)
    for d in range(1, N//2+1):
        if power[d]:
            for n in range(2*d, N+1, d):
                nxt[n] += power[d]
    for n in range(2, N+1):
        if nxt[n]:
            nu[n] += F((-1)**j*nxt[n], j+1)
    power = nxt

prime = [True]*(N+1)
prime[0] = prime[1] = False
for p in range(2, N+1):
    if prime[p]:
        for n in range(2*p, N+1, p):
            prime[n] = False
expected = [F(0) for _ in range(N+1)]
for p in range(2, N+1):
    if prime[p]:
        n, r = p, 1
        while n <= N:
            expected[n] = F(1, r)
            n *= p
            r += 1
response = [F(0) for _ in range(N+1)]
for d in range(1, N//2+1):
    for n in range(2*d, N+1, d):
        response[n] += nu[d]
for n in range(2, N+1):
    assert response[n] == expected[n], (n, response[n], expected[n])

graph_checks = 0
for v in range(2, 12):
    u = [F((-1)**i*(2*i+1), i+2) for i in range(v)]
    left = sum((u[i]+u[j])**2 for i in range(v) for j in range(i+1, v))
    right = (v-2)*sum(x*x for x in u)+sum(u)**2
    assert left == right
    graph_checks += 1

out = {
    'scope': 'Finite exact algebra checks; asymptotic sharpness is proved analytically using PNT.',
    'maximum_integer': N,
    'proper_divisor_response_checks': N-1,
    'complete_signless_graph_checks': graph_checks,
    'sample_coefficients': {str(n):str(nu[n]) for n in [1,11,121,143,1331]},
}
target = Path(__file__).resolve().parents[1]/'results'/'quarter_exact_checks.json'
target.parent.mkdir(exist_ok=True)
target.write_text(json.dumps(out, indent=2)+'\n')
print(f'PASS: {N-1} exact divisor responses and {graph_checks} exact graph identities')
