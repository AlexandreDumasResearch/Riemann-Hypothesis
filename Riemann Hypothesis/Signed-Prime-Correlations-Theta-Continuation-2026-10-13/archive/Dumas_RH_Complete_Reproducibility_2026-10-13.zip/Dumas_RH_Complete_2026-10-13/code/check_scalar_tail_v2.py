#!/usr/bin/env python3
"""Exact rational/symbolic checks for the filtered scalar-tail theorem."""
from fractions import Fraction as Q
import json
import sympy as sp

z, ell = sp.symbols("z ell")
A = 16 - 80*z + 132*z**2 - 80*z**3 + 16*z**4
assert sp.expand(A - 4*(1-2*z)**2*(2-z)**2) == 0
assert sp.expand(z**4*A.subs(z, 1/z) - A) == 0

def Lmath(k):
    if k == 0:
        return sp.Integer(1)
    return (-1)**k*(sp.laguerre(k, 3*ell)-sp.laguerre(k-1, 3*ell))/2

low = sp.expand(132*Lmath(0)-160*Lmath(1)+32*Lmath(2))
assert low == 132 - 288*ell + 72*ell**2
u = sp.symbols("u", positive=True)
assert sp.simplify(sp.integrate(sp.exp(-ell)*low, (ell,u,sp.oo)) - (
    72*u**2-144*u-12)*sp.exp(-u)) == 0
delta_z = (1-2*z)/(1+z)
assert sp.cancel(A/delta_z - 4*(1-2*z)*(2-z)**2*(1+z)) == 0

r = Q(5,36)
delta = (1-2*r)/(1+r)
assert delta == Q(26,41)
assert Q(2,1)/delta == Q(41,13)
Aminus = 4*(1+2*r)**2*(2+r)**2
L = 132+80/r+16/r**2
high = Q(64,2187)*(1+delta)/delta*Aminus*r
low_bound = Q(128,2187)*(1+delta)/delta*L*r**6
assert high == Q(1050707735,3357644238)
assert low_bound == Q(134125625,80583461712)
total = high + low_bound
assert total == Q(25351111265,80583461712)
assert total < Q(1,3)
# Exact proof that 506^n exceeds the optimized rational-radius cutoff.
cutoff_margin = 506**13*5**41 - 36**41
assert cutoff_margin > 0

# At n=3, L*r^(2n) is maximal for all admissible integer n>=3.
assert 0 < r < 1
assert r**8 < r**6

# Saddle second derivative, in the angular variable at zero.
rr, C = sp.symbols("rr C", positive=True)
H = -C*delta_z - 2*sp.log(z)
D = lambda expr: sp.simplify(z*sp.diff(expr,z))
saddle_C = 2*(1+rr)**2/(3*rr)
assert sp.simplify(D(H).subs(z,rr).subs(C,saddle_C)) == 0
assert sp.simplify(D(D(H)).subs(z,rr).subs(C,saddle_C)
                   - 2*(1-rr)/(1+rr)) == 0

print(json.dumps({
    "status": "all exact checks passed",
    "radius": str(r),
    "delta": str(delta),
    "high_tail_bound": str(high),
    "low_tail_bound_at_n3": str(low_bound),
    "total_tail_bound": str(total),
    "total_decimal": float(total),
    "cutoff_comparison_margin": str(cutoff_margin),
}, indent=2))
