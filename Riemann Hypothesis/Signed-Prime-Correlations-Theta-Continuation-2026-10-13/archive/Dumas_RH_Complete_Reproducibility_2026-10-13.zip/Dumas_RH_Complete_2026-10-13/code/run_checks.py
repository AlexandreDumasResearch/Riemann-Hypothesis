"""Replay the integrated finite checks; source reconstruction is optional."""
from pathlib import Path
import argparse
import datetime
import hashlib
import importlib.metadata
import json
import platform
import subprocess
import sys
import time

assert __debug__, "Do not use python -O: assertions are part of the checks."
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--rebuild-source', action='store_true',
                    help='rerun both validated 89-moment source integrations first')
parser.add_argument('--figures', action='store_true',
                    help='regenerate the supplied figures and diagonal table')
parser.add_argument('--diagnostics', action='store_true',
                    help='also run explicitly nonvalidated saddle/constant experiments')
args = parser.parse_args()
base = Path(__file__).resolve().parent
root = base.parent
out = root / 'results'
out.mkdir(exist_ok=True)
jobs = []
if args.rebuild_source:
    jobs += [('fresh_source.py', [], 'validated source reconstruction'),
             ('fresh_source.py', ['--cross-check'], 'independent-parameter reconstruction')]
jobs += [
    ('check.py', [], 'exact algebra and outward interval certificates'),
    ('check_structures.py', [], 'exact finite structural checks'),
    ('check_constants.py', [], 'exact rational constant checks'),
    ('check_quarter.py', [], 'exact divisor and complete-graph checks'),
    ('check_arithmetic_independent_v2.py', [], 'exact finite arithmetic checks'),
    ('check_scalar_tail_v2.py', [], 'exact finite tail checks'),
    ('check_heat_v2.py', [], 'exact finite heat identities'),
    ('check_appendix_v2.py', [], 'exact appendix identities and labeled diagnostics'),
    ('quadratic_checks.py', [], 'exact finite Laguerre and quadratic checks'),
    ('check_theta_covariance_obstruction.py', [], 'exact interval covariance witness'),
    ('certify_sector_constant.py', [], 'outward rational sector-sign certificate'),
    ('certify_sector_sign.py', [], 'independent Arb sector-sign certificate'),
    ('check_residue_replacement.py', [], 'exact finite rational replacement models'),
    ('check_scouting_models.py', [], 'exact lobe and curvature countermodels'),
    ('cross_degree_checks.py', [], 'exact cross-degree Gram and sharp symbol checks'),
    ('check_effective_sector.py', [], 'exact effective sector-tail constants'),
    ('check_analytic_cancellation.py', [], 'exact pointwise identities and labeled floating diagnostics'),
    ('theta_rotation_checks.py', [], 'exact rotated saddle algebra'),
]
if args.diagnostics:
    jobs += [('saddle_v2_replay.py', [], 'nonvalidated theta-saddle diagnostics'),
             ('check_packet_stencil.py', [], 'exact moment checks and nonvalidated saddle ratios'),
             ('prime_sector_constants.py', [], 'nonvalidated constant diagnostics')]
if args.figures:
    jobs += [('figures.py', [], 'figure generation')]
capture = {
    'check_arithmetic_independent_v2.py': 'check_arithmetic_independent_v2.json',
    'check_scalar_tail_v2.py': 'check_scalar_tail_v2.json',
    'certify_sector_sign.py': 'sector_sign_certificate.json',
    'prime_sector_constants.py': 'prime_sector_constants.json',
}
records = []
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
for name, extra, scope in jobs:
    label = Path(name).stem + ('_crosscheck' if extra else '')
    print('Running', name, *extra, flush=True)
    tick = time.monotonic()
    result = subprocess.run([sys.executable, str(base / name), *extra],
                            text=True, capture_output=True)
    log = out / (label + '_stdout.txt')
    log.write_text(result.stdout + result.stderr, encoding='utf-8')
    records.append({'script': name, 'arguments': extra, 'scope': scope,
                    'returncode': result.returncode,
                    'runtime_seconds': time.monotonic() - tick,
                    'stdout': str(log.relative_to(root))})
    if result.returncode:
        print(result.stdout + result.stderr)
        (out / 'integrated_failed_run.json').write_text(json.dumps(records, indent=2) + '\n')
        raise SystemExit(result.returncode)
    if name in capture:
        data = json.loads(result.stdout)
        (out / capture[name]).write_text(json.dumps(data, indent=2) + '\n')
    print('PASS', name, flush=True)
environment = {
    'run_started_utc': started,
    'python': sys.version,
    'platform': platform.platform(),
    'packages': {name: importlib.metadata.version(name)
                 for name in ['sympy', 'mpmath', 'python-flint', 'numpy', 'scipy', 'matplotlib']},
    'source_quadrature_rerun': args.rebuild_source,
    'source_input_sha256': hashlib.sha256((root / 'inputs/fresh_moments_0_88.json').read_bytes()).hexdigest(),
    'diagnostics_requested': args.diagnostics,
    'figures_requested': args.figures,
    'checks': records,
    'all_requested_checks_passed': True,
    'scope': 'Finite exact/interval computations and separately labeled diagnostics; analytic all-order proofs are in the manuscript. RH is unresolved.'
}
(out / 'integrated_replay.json').write_text(json.dumps(environment, indent=2) + '\n')
print('All requested finite checks passed. Analytic all-order proofs are in the manuscript.')
