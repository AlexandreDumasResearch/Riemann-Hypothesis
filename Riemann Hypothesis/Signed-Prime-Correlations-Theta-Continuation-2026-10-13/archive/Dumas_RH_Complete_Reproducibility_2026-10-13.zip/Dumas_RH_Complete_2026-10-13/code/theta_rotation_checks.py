"""Exact algebra checks for opposite-source contour rotations.

These checks verify Taylor and determinant algebra, not analytic contour
estimates or an RH-strength assertion.  Run with Python 3 and SymPy.
"""
from pathlib import Path
import json
import sympy as s

a, b, D, c, tau, y = s.symbols('a b D c tau y', real=True)
checks = []
for z in [s.Integer(1), (4+3*s.I)/5, (12+5*s.I)/13]:
    C = s.simplify((z**2+z**-2)/2)
    h1 = s.sqrt(2)*c*s.sqrt(C)*a/z
    h2 = s.sqrt(2)*c*s.sqrt(C)*b*z
    n = D/(4*c**2)
    x = n/D*(z**2-z**-2)/(2*s.I*C)
    w = (h1+h2)/(2*D)
    moment = 2*n*sum((-1)**(k+1)*w**k/s.Integer(k) for k in range(1, 5))
    source = -n/(2*D*C)*(z**2*sum((2*h1)**k/s.factorial(k) for k in range(1,5))
                           +z**-2*sum((2*h2)**k/s.factorial(k) for k in range(1,5)))
    fourier = s.I*x*(h1-h2)
    amp = s.Rational(9,2)*(h1+h2)
    heat = tau*(2*(D+s.I*y)*h1+2*(D-s.I*y)*h2+h1*h1+h2*h2)
    expansion = s.expand(moment+source+fourier+amp+heat)
    assert s.simplify(expansion.coeff(c,-1)) == 0
    Q = -(a*a+b*b)/2-C/(8*D)*(a/z+b*z)**2
    assert s.simplify(expansion.coeff(c,0)-Q) == 0
    odd = expansion.coeff(c,1)
    assert s.simplify(odd.subs({a:-a,b:-b}, simultaneous=True)+odd) == 0
    vec = s.Matrix([1/z,z])
    matrix = s.eye(2)+C/(4*D)*(vec*vec.T)
    assert s.simplify(matrix.det()-(1+C*C/(2*D))) == 0
    jac = s.Matrix([[s.diff((h1+h2)/2,v) for v in (a,b)],
                    [s.diff((h1-h2)/2,v) for v in (a,b)]]).det()
    assert s.simplify(jac*jac-(c*c*C)**2)==0
    checks.append({'unit_phase':str(z), 'C':str(C),
                   'linear_cancellation':True, 'quadratic_form':True,
                   'cubic_parity':True, 'determinant':True,
                   'jacobian_modulus':True})
out = {'status':'pass', 'scope':'15 exact algebraic checks; no numerical contour certification',
       'checks':checks}
target=Path(__file__).resolve().parents[1] / 'results' / 'theta_rotation_checks.json'
target.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
