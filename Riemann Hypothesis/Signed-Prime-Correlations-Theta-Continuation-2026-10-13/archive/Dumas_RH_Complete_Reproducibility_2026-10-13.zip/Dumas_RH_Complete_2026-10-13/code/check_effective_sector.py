#!/usr/bin/env python3
"""Exact arithmetic checks for the effective sector-tail proof.

This checks integer/rational inequalities and the Laguerre form identity.
It is not a numerical certification of an infinite analytic theorem.
Trudgian's cited explicit PNT theorem is an external proved input.
"""
import json
from fractions import Fraction as Q
from pathlib import Path
from math import comb, factorial

checks = {}
def check(name, value):
    checks[name] = bool(value)
    assert checks[name], name

Aenv=1024
eta=Q(1,16)
I0=2*Aenv/eta**2
I1=12*Aenv/eta**4
G0=Aenv+I0
G1=Q(Aenv,2)+I0+I1
K0=4*Aenv+Q(5,2)*G0
K1=8*G0+Q(13,2)*G1
P1=12*Aenv**2/(2*eta)**4
check('integral_shifted_w',G0==525312)
check('integral_u_shifted_w',G1==805831168)
check('K0_upper',K0==1317376)
check('K1_upper',K1==5242105088)
check('P1_upper',P1==51539607552)
CB=Q(39366*32**2,2187**2)
check('six_band_Bessel_constant',CB==Q(2048,243))
e=[4,24,53,53,24,4]
check('derivative_band_total',sum(e)==162)
check('derivative_band_even',sum(e[::2])==81)
check('derivative_band_odd',sum(e[1::2])==81)

r0=Q(5,36); delta=Q(26,41)
pre=Q(128,2187)*(1+delta)/delta
A=pre*(132+80/r0+16/r0**2)
B=pre*Q(1,2)*4*(1+2*r0)**2*(2+r0)**2*r0
check('cutoff_A_lt_300',A<300)
check('cutoff_B_lt_1',B<1)
check('cutoff_s_lt_1_over_50',506**26>50**41)
check('cutoff_rho_lt_2999_over_3000',36**82*3000**41<5**82*506**26*2999**41)
check('cutoff_denominator_s',1-Q(1,50)**2>Q(9,10))
check('cutoff_denominator_rho',1-Q(2999,3000)**2>Q(1,2000))
check('cutoff_first_coefficient',2*300**2/(1-Q(1,50)**2)<200000)
check('cutoff_first_tail_scaled',4*200000*Q(1,50)**4<1)
check('cutoff_second_tail_scaled',4*4000*30+1<10**6)
CH=8*200**2+Q(2,3)*80000**2
CG=12*1500**2+Q(4,3)*8000**2
Cfull=4*CB*(2*K0+Q(4,3)*K1+Q(3,2)*P1)+(CH+CG)/6+10**6
check('full_constant_lt_3e12',Cfull<3*10**12)
check('PNT_envelope_coarsening',6*(65+64)<1024)
check('small_prime_log_bound',149<Q(8,3)**6)

for n in range(16):
    coeff=[Q((-1)**j*comb(n,j)*3**j,factorial(j)) for j in range(n+1)]+[Q(0)]
    # Conjugating the Laguerre form by exp(-3x/2) reduces it to
    # -x P''+(3x-1)P'-3nP=0.
    check(f'laguerre_form_{n}',all(-(j+1)**2*coeff[j+1]+3*(j-n)*coeff[j]==0 for j in range(n+1)))

result={
    'status':'all exact checks passed',
    'scope':'Exact algebra and inequalities only; analytic estimates proved in accompanying text.',
    'checks':checks,
    'count':len(checks),
    'constants':{k:str(v) for k,v in dict(K0=K0,K1=K1,P1=P1,band=CB,
        cutoff_A=A,cutoff_B=B,fourier_H=CH,fourier_gamma=CG,
        combined_rational_upper=Cfull,displayed_upper=3*10**12).items()},
    'external_input':{'title':'Updating the error term in the prime number theorem',
                     'author':'Tim Trudgian','theorem':1,
                     'doi':'10.1007/s11139-014-9656-6',
                     'author_pdf':'https://arxiv.org/pdf/1401.2689'},
}
path=Path(__file__).resolve().parents[1] / 'results' / 'effective_sector_checks.json'
path.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':result['status'],'count':len(checks),'output':str(path)},indent=2))
