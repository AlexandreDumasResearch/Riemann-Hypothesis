#!/usr/bin/env python3
"""Exact structural checks for the paper's source-heat discriminant section.

Run from any directory with Python 3 and SymPy:
    python /path/to/publication/code/check_structures.py

No floating-point arithmetic or external data enter the checks. The symbolic
tests validate finite instances of the algebraic identities proved in the
paper; they are not tests of the missing all-degree theta sign estimate.
"""

from __future__ import annotations

import argparse
from collections import defaultdict
from itertools import combinations_with_replacement
import json
from pathlib import Path
import platform

import sympy as sp
from sympy.utilities.iterables import multiset_permutations


PUBLICATION = Path(__file__).resolve().parents[1]
HALF = sp.Rational(1, 2)
MOMENTS = sp.symbols("I0:9")
X, T = sp.symbols("x t")


def lower(expr):
    return sp.expand(sum(
        k * (k - HALF) * MOMENTS[k - 1] * sp.diff(expr, MOMENTS[k])
        for k in range(1, len(MOMENTS))
    ))


def raise_heat(expr):
    if MOMENTS[-1] in expr.free_symbols:
        raise ValueError("Moment array too short for a raising operation")
    return sp.expand(sum(
        MOMENTS[k + 1] * sp.diff(expr, MOMENTS[k])
        for k in range(len(MOMENTS) - 1)
    ))


def weight_operator(expr):
    return sp.expand(sum(
        (2 * k + HALF) * MOMENTS[k] * sp.diff(expr, MOMENTS[k])
        for k in range(len(MOMENTS))
    ))


def raw_jensen(n):
    return sp.expand(sum(
        (-1) ** k * sp.binomial(n, k) * MOMENTS[k]
        / sp.rf(HALF, k) * X ** (n - k)
        for k in range(n + 1)
    ))


def assert_zero(expr, label):
    residual = sp.expand(expr)
    if residual != 0:
        raise AssertionError(f"{label}: nonzero exact residual {residual}")


def moment_degree_pairs(expr):
    return sorted({
        (sum(exponents), sum(k * e for k, e in enumerate(exponents)))
        for exponents, _ in sp.Poly(expr, *MOMENTS).terms()
    })


def polarized_bessel_check(expr, slots):
    """Independent coefficient-dictionary check after full polarization.

    Expanding each distinct exponent orbit gives its symmetric average.
    The squared-Bessel operator then acts directly on source-slot exponents,
    independently of the formal moment-derivation implementation above.
    """
    beta = defaultdict(lambda: sp.S.Zero)
    for exponents, coefficient in sp.Poly(expr, *MOMENTS).terms():
        powers = [k for k, multiplicity in enumerate(exponents)
                  for _ in range(multiplicity)]
        if len(powers) != slots:
            raise AssertionError("Wrong polarization degree")
        denominator = sp.factorial(slots)
        for multiplicity in exponents:
            denominator /= sp.factorial(multiplicity)
        orbit_coefficient = coefficient / denominator
        for perm in multiset_permutations(powers):
            beta[tuple(perm)] += orbit_coefficient
    beta = {powers: coefficient for powers, coefficient in beta.items()
            if coefficient != 0}
    residual = defaultdict(lambda: sp.S.Zero)
    for powers, coefficient in beta.items():
        for slot, k in enumerate(powers):
            if k:
                lowered = list(powers)
                lowered[slot] -= 1
                residual[tuple(lowered)] += coefficient * k * (k - HALF)
    nonzero = {powers: coefficient for powers, coefficient in residual.items()
               if coefficient != 0}
    if nonzero:
        raise AssertionError(f"Polarized Bessel residual: {nonzero}")
    return {
        "source_slots": slots,
        "expanded_polarization_terms": len(beta),
        "nonzero_bessel_residual_terms": len(nonzero),
    }


def check_commutators():
    monomials = [sp.S.One]
    for degree in range(1, 4):
        monomials += [sp.prod(MOMENTS[k] for k in indices)
                      for indices in combinations_with_replacement(range(5), degree)]
    for i, monomial in enumerate(monomials):
        assert_zero(lower(raise_heat(monomial)) - raise_heat(lower(monomial))
                    - weight_operator(monomial), f"[L,R]=H, monomial {i}")
        assert_zero(weight_operator(raise_heat(monomial))
                    - raise_heat(weight_operator(monomial)) - 2 * raise_heat(monomial),
                    f"[H,R]=2R, monomial {i}")
        assert_zero(weight_operator(lower(monomial))
                    - lower(weight_operator(monomial)) + 2 * lower(monomial),
                    f"[H,L]=-2L, monomial {i}")
    return {
        "monomial_variables": [str(s) for s in MOMENTS[:5]],
        "maximum_total_degree": 3,
        "monomials_checked": len(monomials),
        "identities_per_monomial": 3,
        "exact_zero_residuals": 3 * len(monomials),
    }


def check_degree(n):
    polynomial = raw_jensen(n)
    discriminant = sp.expand(sp.discriminant(polynomial, X))
    c_n = 2 * (n - 1) * (2 * n + 1)
    barrier = sp.expand(c_n * MOMENTS[1] * discriminant
                        - MOMENTS[0] * raise_heat(discriminant))
    assert_zero(lower(polynomial) + sp.diff(polynomial, X), "L P_N=-P_N'")
    assert_zero(lower(discriminant), "L J_N=0")
    assert_zero(lower(barrier), "L B_N=0")
    assert_zero(weight_operator(discriminant) - sp.Rational(c_n, 2) * discriminant,
                "H J_N=(c_N/2)J_N")
    coupling = sp.Rational(c_n, 2) * raise_heat(MOMENTS[0]) * discriminant \
        - HALF * MOMENTS[0] * raise_heat(discriminant)
    assert_zero(barrier - 2 * coupling, "B_N=2 T(I0,J_N)")
    expected_degrees = {
        "discriminant": [(2 * n - 2, n * (n - 1))],
        "barrier": [(2 * n - 1, n * (n - 1) + 1)],
    }
    actual_degrees = {
        "discriminant": moment_degree_pairs(discriminant),
        "barrier": moment_degree_pairs(barrier),
    }
    if actual_degrees != expected_degrees:
        raise AssertionError(f"Unexpected degree data: {actual_degrees}")

    point_mass = {moment: T ** k for k, moment in enumerate(MOMENTS)}
    disc_delta = sp.expand(discriminant.subs(point_mass))
    barrier_delta = sp.expand(barrier.subs(point_mass))
    expected_disc = T ** (n * (n - 1)) * sp.prod(
        sp.Integer(j) ** j * (sp.Integer(j) - HALF) ** (j - 1)
        for j in range(1, n + 1)
    ) / sp.rf(HALF, n) ** (2 * n - 2)
    assert_zero(disc_delta - expected_disc, "Point-mass Laguerre discriminant")
    assert_zero(barrier_delta - 4 * n * (n - 1) * T * disc_delta,
                "Point-mass barrier identity")
    disc_coefficient = disc_delta.coeff(T, n * (n - 1))
    barrier_coefficient = barrier_delta.coeff(T, n * (n - 1) + 1)
    if not (disc_coefficient > 0 and barrier_coefficient > 0):
        raise AssertionError("Nonpositive point-mass coefficient")
    unit_point_mass = sp.Poly(polynomial.subs({i: 1 for i in MOMENTS}), X)
    positive_roots = int(unit_point_mass.count_roots(0, sp.oo))
    if positive_roots != n or unit_point_mass.eval(0) == 0:
        raise AssertionError("Point-mass root count failed")

    record = {
        "N": n,
        "discriminant_moment_terms": len(sp.Poly(discriminant, *MOMENTS).terms()),
        "barrier_moment_terms": len(sp.Poly(barrier, *MOMENTS).terms()),
        "moment_degree_pairs": actual_degrees,
        "exact_identity_checks": {
            "L_P_plus_dx_P": True,
            "L_J": True,
            "L_B": True,
            "H_J_minus_c_over_2_J": True,
            "B_minus_2_transvectant": True,
            "point_mass_discriminant_formula": True,
            "point_mass_barrier_formula": True,
        },
        "point_mass": {
            "discriminant_coefficient": str(disc_coefficient),
            "barrier_coefficient": str(barrier_coefficient),
            "both_coefficients_positive": True,
            "positive_roots_at_t_1_exact_sturm_count": positive_roots,
            "roots_simple": bool(disc_coefficient != 0),
        },
    }
    if n <= 4:
        record["independent_polarized_bessel_check"] = polarized_bessel_check(
            barrier, 2 * n - 1)
    return record


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path,
                        default=PUBLICATION / "results" / "structure_checks.json")
    args = parser.parse_args()
    commutators = check_commutators()
    degrees = [check_degree(n) for n in (2, 3, 4, 5)]
    result = {
        "status": "PASS",
        "arithmetic": "exact rational polynomial arithmetic; no numerical sampling",
        "scope": "Finite symbolic instances of identities proved for all degrees in the paper.",
        "does_not_certify": "The unbounded-degree theta sign or subexponential-growth target.",
        "software": {"python": platform.python_version(), "sympy": sp.__version__},
        "commutators": commutators,
        "degrees": degrees,
        "summary": {
            "jensen_degrees_checked": [2, 3, 4, 5],
            "degree_specific_zero_identities": sum(len(d["exact_identity_checks"]) for d in degrees),
            "commutator_zero_identities": commutators["exact_zero_residuals"],
            "point_mass_positive_root_counts": len(degrees),
            "independent_polarized_bessel_degrees": [2, 3, 4],
        },
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": result["status"], "output": str(args.output),
                      **result["summary"]}, indent=2))


if __name__ == "__main__":
    main()
