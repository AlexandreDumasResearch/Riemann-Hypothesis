from pathlib import Path
import subprocess,sys,json,datetime,os,importlib.metadata
base=Path(__file__).resolve().parents[1]
records=[]
for name in ['cross_degree_checks.py','check_effective_sector.py','check_analytic_cancellation.py','theta_rotation_checks.py']:
 r=subprocess.run([sys.executable,str(base/'code'/name)],capture_output=True,text=True)
 (base/'results'/(Path(name).stem+'_stdout.txt')).write_text(r.stdout+r.stderr)
 records.append({'script':name,'returncode':r.returncode})
 assert r.returncode==0,r.stdout+r.stderr
 print('PASS',name,flush=True)
result={'run_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'python':sys.version,'packages':{p:importlib.metadata.version(p) for p in ['sympy','numpy','scipy']},'checks':records,'source_quadrature_rerun':False,'scope':'Focused exact algebra and rational-constant replay; pointwise floating samples are diagnostics only. Infinite analytic proofs are in the paper.'}
(base/'results/quantitative_replay.json').write_text(json.dumps(result,indent=2)+'\n')
