#!/usr/bin/env python3
"""Exact finite algebra supporting quadratic_results.md; not an RH certificate."""
from fractions import Fraction as F
from pathlib import Path
import json
import sympy as s

checks = 0

def check(x):
    global checks
    assert x
    checks += 1

kappa = s.Rational(32,2187)
x = s.symbols('x')
d = (8,32,26,-26,-32,-8)
e = (4,24,53,53,24,4)
low = (52,64,16)
low_d = (-106,-48,-8)

def coeffs(m, derivative=False):
    a = {}
    for j,v in enumerate(low_d if derivative else low):
        a[j]=a.get(j,0)+v
    for j,v in enumerate(e if derivative else d):
        k=2*m-2+j
        a[k]=a.get(k,0)+v
    return a

def energy(a, weighted=False):
    if not weighted: return sum(v*v for v in a.values())
    return sum((2*k+1)*v*v for k,v in a.items())-2*sum((k+1)*v*a.get(k+1,0) for k,v in a.items())

def ell(k):
    if k==0: return s.Integer(1)
    return s.Rational((-1)**k,2)*(s.laguerre(k,x)-s.laguerre(k-1,x))

for m in range(1,13):
    direct=132*ell(0)-160*ell(1)+32*ell(2)
    for j,v in enumerate((16,-80,132,-80,16)):
        direct += v*ell(2*m-1+j)
    band=sum(v*s.laguerre(k,x) for k,v in coeffs(m).items())
    deriv=sum(v*s.laguerre(k,x) for k,v in coeffs(m,True).items())
    check(s.expand(direct-band)==0)
    check(s.expand(s.diff(band,x)-band/2-deriv)==0)
    check(s.expand(band).subs(x,0)==132)
    check(s.expand(deriv).subs(x,0)==0)

for m in range(3,101):
    check(energy(coeffs(m))==10584)
    check(energy(coeffs(m,True))==20406)
    check(energy(coeffs(m),True)==8112*m+9576)
    check(energy(coeffs(m,True),True)==5028*m+9270)

check(s.factor(kappa**2*s.Rational(8112,9))==s.Rational(2768896,14348907))
check(energy(dict(enumerate(low)),True)==5520)
check(sum(d)==0)
check(sum(e)==162)

# Finite moving-cutoff and general cross-degree identities, tested with formal
# independent entries. Exact cutoffs determine inclusion; these identities do
# not depend on substituting numerical logarithms into the kernel entries.
N=4
nodes=[2,3,int(s.nextprime(506**3)),int(s.nextprime(506**4)),int(s.nextprime(506**5))]
b=s.symbols('b0:'+str(len(nodes)))
v={(m,j):s.Symbol('q%d_%d'%(m,j)) for m in range(1,N+1) for j in range(len(nodes))}
U={m:sum(b[j]*v[m,j] for j,p in enumerate(nodes) if p<=506**(m+2)) for m in range(1,N+1)}
lhs=sum(U[m]**2 for m in range(1,N+1))
rhs=0
for j,p in enumerate(nodes):
    for k,q in enumerate(nodes):
        rhs += b[j]*b[k]*sum(v[m,j]*v[m,k] for m in range(1,N+1) if p<=506**(m+2) and q<=506**(m+2))
check(s.expand(lhs-rhs)==0)
for m in range(1,N+1):
    for n in range(1,N+1):
        rhs=sum(b[j]*b[k]*v[m,j]*v[n,k] for j,p in enumerate(nodes) for k,q in enumerate(nodes) if p<=506**(m+2) and q<=506**(n+2))
        check(s.expand(U[m]*U[n]-rhs)==0)

# Exact finite trigonometric-sum identity expressed with z=e^(iu).
z=s.symbols('z', nonzero=True)
for M,N in [(1,1),(1,5),(2,7)]:
    C=sum((z**(2*m+1)+z**(-2*m-1))/2 for m in range(M,N+1))
    closed=(z**(N-M+1)-z**(-(N-M+1)))/(z-z**(-1))*(z**(M+N+1)+z**(-(M+N+1)))/2
    check(s.factor(C-closed)==0)

out={
 'status':'PASS', 'exact_assertions':checks,
 'scope':'Finite algebra, Laguerre derivative and norm identities, moving cutoff expansion. Does not computationally certify RH or the analytic PNT-based asymptotic proof.',
 'linear_diagonal_constant':str(s.Rational(2768896,14348907)),
 'low_degree_norms':[{ 'm':m, 'R_squared':energy(coeffs(m)), 'T_squared':energy(coeffs(m,True)), 'x_R_squared':energy(coeffs(m),True), 'x_T_squared':energy(coeffs(m,True),True)} for m in [1,2]],
 'software':{'sympy':s.__version__},
}
(Path(__file__).resolve().parents[1]/'results'/'quadratic_checks.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
