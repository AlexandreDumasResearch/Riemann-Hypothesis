#!/usr/bin/env python3
"""Exact finite-band checks for the cross-degree prime sampling theorem.
No prime computation or asymptotic numerical experiment is used.
"""
from fractions import Fraction as F
import json
from pathlib import Path
D=(8,32,26,-26,-32,-8)
E=(4,24,53,53,24,4)
A=(8112,-5112,960,128)
checks=0

def test(statement):
    global checks
    assert statement
    checks+=1

def band(m,d):return {2*m-2+j:F(x) for j,x in enumerate(d)}
def xinner(c,d):
    return sum(v*((2*k+1)*d.get(k,0)-(k+1)*d.get(k+1,0)-k*d.get(k-1,0)) for k,v in c.items())
def deriv(c):
    out={k:-v/2 for k,v in c.items()}
    for k,v in c.items():
        for j in range(k):out[j]=out.get(j,0)-v
    return {k:v for k,v in out.items() if v}
def add(a,b):
    c=a.copy()
    for k,v in b.items():c[k]=c.get(k,0)+v
    return {k:v for k,v in c.items() if v}
for m in range(1,61):
    test(deriv(band(m,D))==band(m,E))
    for k in range(11):
        expected=A[k]*(F(m)+F(k+1,2)) if k<len(A) else 0
        test(xinner(band(m,D),band(m+k,D))==expected)
for m in range(1,20):
  for n in range(1,20):test(xinner(band(m,D),band(n,D))==xinner(band(n,D),band(m,D)))
# Synthesis bounds retain complete parity filters.
test(sum(abs(x) for x in D)==132)
test(sum(abs(x) for x in D[::2])==sum(abs(x) for x in D[1::2])==66)
test(F(132*66,3)==2904)
test(sum(E)==162)
test(sum(E[::2])==sum(E[1::2])==81)
test(3*162*81==39366)
test(2904*39366==10692**2)
# Symbol in t=cos(theta), using cos2=2t²-1 and cos3=4t³-3t.
poly=(A[0]-2*A[2],2*A[1]-6*A[3],4*A[2],8*A[3])
test(poly==(6192,-10992,3840,1024))
test(sum(poly)==64)
test(sum(v*((-1)**k) for k,v in enumerate(poly))==20000)
test(poly[1]+2*poly[2]+3*poly[3]==-240)
test(poly[1]-2*poly[2]+3*poly[3]==-15600)
test(F(sum(abs(A[k])*k*k for k in (1,2,3)),36)==F(842,3))
# Linear energy for adjacent sum/difference; all cross bands retained.
test(2*A[0]+2*A[1]==6000)
test(2*A[0]-2*A[1]==26448)
# Evaluate exact form against the band representation for a finite complex-free vector.
for start in (1,2,3,10,50):
 for u in ((1,1),(1,-1),(1,-2,1),(1,3,-4,2,-2),(1,0,0,0,-1)):
    c={}
    for j,uj in enumerate(u):c=add(c,{k:uj*v for k,v in band(start+j,D).items()})
    rhs=sum(F(uj*uk)*A[abs(j-k)]*F(2*start+j+k+1,2) for j,uj in enumerate(u) for k,uk in enumerate(u) if abs(j-k)<=3)
    test(xinner(c,c)==rhs)
result={"status":"passed","exact_assertions":checks,"lag_slopes":A,"symbol_polynomial_in_cosine":poly,"symbol_min":64,"symbol_max":20000,"normalized_jacobi_remainder_numerator":"842/3","scope":"exact algebra only; the infinite-dimensional prime operator theorem is established analytically"}
path=Path(__file__).resolve().parents[1] / 'results' / 'cross_degree_checks.json'
path.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
