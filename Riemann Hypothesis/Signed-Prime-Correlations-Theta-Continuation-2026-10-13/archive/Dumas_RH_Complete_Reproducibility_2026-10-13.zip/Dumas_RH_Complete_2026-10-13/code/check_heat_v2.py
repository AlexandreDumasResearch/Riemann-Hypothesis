#!/usr/bin/env python3
"""Independent exact checks for heat_v2; not a proof of unbounded degree signs."""
import itertools, json, math
from pathlib import Path
import sympy as s

x=s.symbols('x'); I=s.symbols('I0:9'); checks={}; details={}
def ck(name, value):
    checks[name]=bool(value)
    if not checks[name]: raise AssertionError(name)
def poly(n):
    return sum((-1)**k*s.binomial(n,k)*I[k]/s.rf(s.Rational(1,2),k)*x**(n-k) for k in range(n+1))
def lower(q):
    return s.expand(sum(k*(k-s.Rational(1,2))*I[k-1]*s.diff(q,I[k]) for k in range(1,len(I))))
def raise_(q):
    return s.expand(sum(I[k+1]*s.diff(q,I[k]) for k in range(len(I)-1)))
def polar(q, m):
    y=s.symbols('y:'+str(m)); out=0
    for powers,c in s.Poly(q,*I).terms():
        exps=tuple(k for k,p in enumerate(powers) for _ in range(p))
        assert len(exps)==m
        distinct=set(itertools.permutations(exps))
        out+=c*sum(s.prod(v**a for v,a in zip(y,pp)) for pp in distinct)/len(distinct)
    return y,s.expand(out)
for n in range(1,7):
    p=poly(n)/I[0]; pn=poly(n+1)/I[0]; mu1=I[1]/I[0]
    ck(f'Appell_{n}',s.expand(s.diff(pn,x)-(n+1)*p)==0)
    rhs=-x*x*s.diff(p,x)+((2*n+s.Rational(1,2))*x-mu1)*p-(n+s.Rational(1,2))*pn
    ck(f'heat_{n}',s.cancel(raise_(p)-rhs)==0)
for n in range(2,5):
    j=s.discriminant(poly(n),x); c=2*(n-1)*(2*n+1); b=s.expand(c*I[1]*j-I[0]*raise_(j))
    ck(f'lower_discriminant_{n}',lower(j)==0)
    ck(f'lower_barrier_{n}',lower(b)==0)
    delta={I[k]:s.Integer(1) for k in range(len(I))}
    jd=s.prod(s.Integer(k)**k*(s.Rational(2*k-1,2))**(k-1) for k in range(1,n+1))/s.rf(s.Rational(1,2),n)**(2*n-2)
    ck(f'Laguerre_diagonal_{n}',j.subs(delta)==jd)
    ck(f'barrier_diagonal_{n}',b.subs(delta)==4*n*(n-1)*jd)
    if n<=3:
        m=2*n-1; ell=n*(n-1)+1; lam=ell*(ell+s.Rational(m,2)-1)
        y,beta=polar(b,m); center={v:s.Rational(1,m) for v in y}; b0=beta.subs(center)
        ck(f'polar_harmonic_{n}',s.expand(sum(v*s.diff(beta,v,2)+s.diff(beta,v)/2 for v in y))==0)
        direction={y[0]:s.Rational(1,m)+x,y[1]:s.Rational(1,m)-x,**{v:s.Rational(1,m) for v in y[2:]}}
        ck(f'barycentric_hessian_{n}',s.diff(beta.subs(direction),x,2).subs(x,0)==-2*m*lam*b0/(m-1))
        for r in range(ell):
            # Orthogonality to y_0^r, enough as a sample; general theorem is analytic.
            integ=0
            for powers,coef in s.Poly(s.expand(beta*y[0]**r),*y).terms():
                integ+=coef*s.prod(s.rf(s.Rational(1,2),a) for a in powers)/s.rf(s.Rational(m,2),sum(powers))
            ck(f'angular_low_coefficient_{n}_{r}',integ==0)
# The exact two-atom source (4/5)delta_0 + (1/5)delta_1.
a=s.Rational(4,5); b=s.Rational(1,5); E=s.symbols('E',positive=True)
mom={I[0]:a+b*E,**{I[k]:b*E for k in range(1,len(I))}}
j2=s.factor(s.discriminant(poly(2),x).subs(mom))
B2=s.expand((10*I[1]*s.discriminant(poly(2),x)-I[0]*raise_(s.discriminant(poly(2),x))).subs(mom))
ck('two_atom_cold_negative_discriminant',j2.subs(E,1)==-s.Rational(32,75))
ck('two_atom_cold_negative_barrier',B2.subs(E,1)==-s.Rational(64,75))
ck('two_atom_collision_E2',j2.subs(E,2)==0)
ck('two_atom_high_derivatives_from_r3',16*3**3>52*2**3)
details['two_atom_raw_discriminant']=str(j2); details['two_atom_raw_barrier']=str(B2)
# The primitive counterexample and the recovered single-valley rule.
p=s.prod(x-v for v in [s.Rational(1,5),s.Rational(2,5),s.Rational(8,5),s.Rational(9,5)])
B=s.integrate(5*p,x); roots=[s.Rational(1,5),s.Rational(2,5),s.Rational(8,5),s.Rational(9,5)]
lo=max(-B.subs(x,r) for r in roots if s.diff(p,x).subs(x,r)<0)
hi=min(-B.subs(x,r) for r in roots if s.diff(p,x).subs(x,r)>0)
ck('empty_primitive_window',lo==-s.Rational(838,9375) and hi==-s.Rational(2754,3125) and lo>hi)
for n in range(2,15):
    for k in range(1,n):
        areas=[s.Rational(1,3)+(j-k)**2 for j in range(1,n)]
        theta=[s.Rational(2,7)]
        for i,a_ in enumerate(areas,1): theta.append(theta[-1]+(-1)**(n-i+1)*a_)
        L=max(theta[i-1] for i in range(1,n+1) if (-1)**(n-i)<0)
        U=min(theta[i-1] for i in range(1,n+1) if (-1)**(n-i)>0)
        ck(f'single_valley_{n}_{k}',U-L==min(areas))
# Exact distinct-key collision surplus and degenerate sharpness.
y=s.symbols('v:4'); S=lambda k:sum(t**k for t in y)
ck('distinct_key_dispersion',s.expand(S(2)*S(4)-S(3)**2-sum(y[i]**2*y[j]**2*(y[i]-y[j])**2 for i in range(4) for j in range(i+1,4)))==0)
alpha,eta=s.symbols('alpha eta', real=True)
for d in range(2,9):
    quadratic=(alpha**2+eta**2)*x*x-2*alpha*d*x+d*(d-1)
    ck(f'degenerate_sector_sharpness_{d}',s.expand(s.discriminant(quadratic,x)-4*d*(alpha**2-(d-1)*eta**2))==0)
# Endpoint normalization and exact constants for the positive reference mode.
u,aa=s.symbols('u aa', positive=True)
mode=(8*aa**2*s.exp(s.Rational(9,2)*u)-12*aa*s.exp(s.Rational(5,2)*u))*s.exp(-aa*s.exp(2*u))
ck('mode_endpoint_derivative',s.simplify(s.diff(mode,u).subs(u,0)+2*aa*s.exp(-aa)*(8*aa**2-30*aa+15))==0)
ck('mode_quadratic_positive_after12',s.Poly(s.expand((8*aa**2-30*aa+15).subs(aa,12+x)),x).all_coeffs()==[8,162,807])
e=s.Rational(1,24); lowerbound=1-5*e/(1-e)
ck('reference_mass_constant',lowerbound==s.Rational(18,23))
ck('reference_A_constant',(5*e/(1-e)**2)/lowerbound==s.Rational(20,69))
ck('reference_B_constant',(5*e*(1+3*e)/(2*(1-e)**3))/lowerbound==s.Rational(90,529))
ck('reference_C_below_half',s.Rational(730,1587)<s.Rational(1,2))
z=s.Rational(12,11); M=12
exp_upper=sum(z**j/s.factorial(j) for j in range(M+1))+z**(M+1)/s.factorial(M+1)/(1-z/(M+2))
ck('exp12over11_below3',exp_upper<3)
out=Path(__file__).resolve().parents[1]/'results'/'heat_v2_exact.json'; out.parent.mkdir(exist_ok=True)
out.write_text(json.dumps({'scope':'finite exact symbolic replay; no all-degree theta positivity certificate','checks':checks,'details':details,'all_passed':all(checks.values())},indent=2)+'\n')
print(json.dumps({'output':str(out),'checks':len(checks),'all_passed':all(checks.values())}))
