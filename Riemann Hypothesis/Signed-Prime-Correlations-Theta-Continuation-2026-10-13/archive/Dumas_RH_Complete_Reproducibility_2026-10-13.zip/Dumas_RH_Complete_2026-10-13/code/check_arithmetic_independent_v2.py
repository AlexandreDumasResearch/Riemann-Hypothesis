#!/usr/bin/env python3
"""Independent exact checks of Sections 2--6 and the v2 average kernel.

No floating arithmetic is used in any assertion. These finite identities
check transcription/algebra; the uniform theorems are proved in the text.
"""
import json
from fractions import Fraction as F
import sympy as s

ell, y, x, z, aa = s.symbols('ell y x z aa')
a=s.Rational(3,2); b=s.Rational(16,9)
checks={}

def p(k):
    return s.expand(2**(k+1)/(s.factorial(k)*aa**(k+1))*sum(
        s.factorial(k+j)*ell**(k-j)/(s.factorial(j)*s.factorial(k-j)*(2*aa)**j)
        for j in range(k+1)))

# Independent differentiation in the resolvent parameter.
for k in range(12):
    assert s.expand(p(k+1)-2/(aa*(k+1))*(ell*p(k)-s.diff(p(k),aa)))==0
checks['reverse_bessel_parameter_recurrence']='degrees 0 through 12'

def V(k, xx=x):
    if k==0: return s.Integer(1)
    v0,v1=s.Integer(1),2*xx-1
    for j in range(1,k): v0,v1=v1,s.expand(2*xx*v1-v0)
    return v1

def L(k):
    if k==0:return s.Integer(1)
    return s.expand((-1)**k*(s.laguerre(k,3*ell)-s.laguerre(k-1,3*ell))/2)

def W(poly):
    return s.expand(sum(c*p(k[0]+1).subs(aa,a) for k,c in s.Poly(poly,y).terms()))

# Verify the cosine coefficient identity by exact polynomial contraction.
for i in range(6):
    for j in range(6):
        poly=s.expand(V(i,2*y/b-1)*V(j,2*y/b-1))
        assert s.expand(W(poly)-s.Rational(32,27)*(L(abs(i-j))+L(i+j+1)))==0
checks['laguerre_bilinear_kernel']='all 36 pairs 0 <= i,j <= 5'

for m in range(1,10):
    pm=(y-2)*V(m,2*y/b-1)
    stencil=s.Rational(32,2187)*(132*L(0)-160*L(1)+32*L(2)+16*L(2*m-1)-80*L(2*m)+132*L(2*m+1)-80*L(2*m+2)+16*L(2*m+3))
    assert s.expand(W(pm**2)-stencil)==0
    # Exact integral against exp(-ell), with every monomial retained.
    integ=sum(c*s.factorial(k[0]) for k,c in s.Poly(stencil,ell).terms())
    assert integ==-s.Rational(128,729)
assert s.expand(W((y-2)**2)-s.Rational(64,2187)*(18*ell**3-90*ell**2+39*ell+26))==0
checks['filtered_stencil_and_continuous_mean']='m=1 through 9, plus exceptional m=0'

# Third-order annihilator of V_m(x)^2.
den=s.Poly((1-z)*((1+z)**2-4*x*x*z),z)
num=1+(2-4*x)*z+z*z
for k in range(15):
    coeff=sum(den.nth(j)*V(k-j)**2 for j in range(min(k,3)+1))
    assert s.expand(coeff-s.expand(num).coeff(z,k))==0
checks['squared_chebyshev_generating_function']='coefficients 0 through 14'

# Pairwise generalized-Li identity, including k=0.
lam=lambda k: 2-2*(-1)**abs(k)*s.chebyshevt(abs(k),x)
for k in range(12):
    assert s.expand(lam(k+1)-2*lam(k)+lam(k-1)-4*(-1)**k*(x+1)*s.chebyshevt(k,x))==0
checks['generalized_li_second_difference']='k=0 through 11'

# Exact degree-average spectrum, including its removable endpoint.
for N in range(1,13):
    left=(1+x)*sum(V(m)**2 for m in range(N))
    right=N+s.chebyshevu(2*N-1,x)/2
    assert s.expand(left-right)==0
    assert s.chebyshevu(2*N-1,-1)==-2*N
checks['degree_average_spectrum']='N=1 through 12'
qlim=s.Rational(8,9)*(p(2)-4*p(1)+4*p(0)).subs(aa,a)
assert s.expand(qlim-(s.Rational(256,243)*ell**2-s.Rational(1024,243)*ell+s.Rational(1408,729)))==0
assert s.Rational(1408,729)-s.Rational(1664,2187)==s.Rational(2560,2187)
checks['degree_average_limit_and_exceptional_norm']='exact'

# Curvature witnesses are evaluated as rational arithmetic from scratch.
c=F(314159,100000)
machin=16*sum((F(-1)**k)*F(1,5)**(2*k+1)/F(2*k+1) for k in range(6))-F(4,239)
assert machin>c
from math import factorial
assert sum((3*c)**k/F(factorial(k)) for k in range(61))>F(10**8,8071)
assert sum((5*c)**k/F(factorial(k)) for k in range(81))>F(10**9,151)
variance=128*(3*c+1)**2*F(8071,10**8)/(1-36*F(151,10**9))
assert variance==F(8771226203214559,7812457531250000)<F(9,8)
assert F(96,5)-F(9,8)==F(723,40)
# log(2)=2 sum_{j>=0} 1/((2j+1)3^(2j+1)); positive lower bound.
log2lower=2*sum(F(1,(2*j+1)*3**(2*j+1)) for j in range(8))
assert 6*F(20,179)<log2lower
checks['curvature_and_zero_disk_rational_witnesses']='all exact inequalities passed'

# Adversarial phase configuration with no positive pole: D(z)=1/(1+2z).
# Odd-index negative coefficients are missed by the even subsequence.
adverse=[(-2)**m for m in range(32)]
assert all(adverse[m]>0 for m in range(0,32,2))
assert all(adverse[m]<0 for m in range(1,32,2))
checks['adversarial_subsequence']='even indices miss every negative excursion'
print(json.dumps({'status':'all exact checks passed','checks':checks},indent=2))
