"""Exact algebra and rational-interval checks for the master research paper.

General conclusions rely on the proofs in the manuscript, not finite tests.
The theta diagonal checks use 89 freshly reconstructed source intervals.
The ordinary-prime calculation does not use the source intervals.
"""
from __future__ import annotations
import json, math, time, hashlib
from pathlib import Path
from fractions import Fraction as Q
from collections import Counter
import sympy as s
from intervals import IV, dec_bounds
import arithmetic as old
BASE=Path(__file__).resolve().parent.parent
OUT=BASE/'results';OUT.mkdir(exist_ok=True)
x,z,y,l=s.symbols('x z y l'); b=s.Rational(16,9); a=s.Rational(3,2); c=s.Rational(32,27)
checks=Counter()
def require(expr,tag):
    assert s.cancel(expr)==0,(tag,expr)
    checks[tag]+=1

def rat(v):
    v=s.Rational(v);return Q(int(v.p),int(v.q))

def V(m,X=x):
    return s.expand(s.chebyshevu(m,X)-(s.chebyshevu(m-1,X) if m else 0))

def coeff(p,var=y):
    p=s.Poly(p,var);return [rat(p.nth(k)) for k in range(p.degree()+1)]

def W_from_square(P):
    cc=coeff(s.expand(P*P))
    return s.expand(sum(s.Rational(t.numerator,t.denominator)*old.p_bessel(k+1,l) for k,t in enumerate(cc)))

def Lag(k):
    return s.Integer(1) if k==0 else s.expand(s.Rational((-1)**k,2)*(s.laguerre(k,3*l)-s.laguerre(k-1,3*l)))

def form_square(P,ss):
    cc=coeff(s.expand(P*P))
    return sum((t*ss[k+2] for k,t in enumerate(cc)),IV(0))

def ivout(v,d=24):return {'rational':v.out(),'decimal':dec_bounds(v,d)}

def fast_log_integer(p):
    e=p.bit_length()-1
    return e*old.LOG2+old.log_unit(Q(p,2**e),45)

assert __debug__, "Run without python -O: exact checks require assertions."
start=time.time()
# Rational generating function for squared Chebyshev-third-kind values.
D=(1-z)*((1+z)**2-4*x*x*z)
G=(1+(2-4*x)*z+z*z)/D
Vs=[V(k) for k in range(17)]
# Verify the rational recurrence rather than expanding a large rational series.
for k in range(17):
    numer=Vs[k]**2
    if k>=1:numer-=(4*x*x-1)*Vs[k-1]**2
    if k>=2:numer+=(4*x*x-1)*Vs[k-2]**2
    if k>=3:numer-=Vs[k-3]**2
    require(numer-(1 if k==0 or k==2 else 2-4*x if k==1 else 0),'squared V generating recurrence')
# A denominator root is nonremovable unless x=0 or 1.
require((1+(2-4*x)*z+z*z)-((1+z)**2-4*x*x*z)-4*x*(x-1)*z,'pole numerator remainder')

for m in range(1,11):
    P=(y-2)*V(m,2*y/b-1)
    # Fixed three-band filter, and exact norm.
    require(P-(s.Rational(4,9)*V(m-1,2*y/b-1)-s.Rational(10,9)*V(m,2*y/b-1)+s.Rational(4,9)*V(m+1,2*y/b-1)),'pole filter')
    W=W_from_square(P)
    require(W.subs(l,0)-s.Rational(1408,729),'constant filtered norm')
    fixed=132*Lag(0)-160*Lag(1)+32*Lag(2)
    band=16*Lag(2*m-1)-80*Lag(2*m)+132*Lag(2*m+1)-80*Lag(2*m+2)+16*Lag(2*m+3)
    require(W-c*(fixed+band)/81,'five-term scalar prime test')
    require(P.subs(y,2),'exact pole neutrality')
    mean=sum(W.coeff(l,j)*s.factorial(j) for j in range(s.degree(W,l)+1))
    require(mean+s.Rational(128,729),'filtered continuous prime mean')
# Finite spectral models: multiple nonreal zeros, with mirrored cancellation excluded.
models=[]
for mult in [1,2,3]:
    beta=s.Rational(1,20)+s.I*s.Rational(1,10)
    betas=[beta]*mult+[s.conjugate(beta)]*mult+[s.Rational(1,30),s.Rational(1,60)]
    ds=[s.cancel(b/2*sum(B*s.chebyshevt(k,2*B/b-1) for B in betas)) for k in range(24)]
    vals=[]
    for m in range(1,10):
        P=(y-2)*V(m,2*y/b-1)
        H=s.cancel(sum(B*B*P.subs(y,B)**2 for B in betas))
        hh=(132*ds[0]-160*ds[1]+32*ds[2]+16*ds[2*m-1]-80*ds[2*m]+132*ds[2*m+1]-80*ds[2*m+2]+16*ds[2*m+3])/81
        require(H-hh,'spectral five-term diagonal including multiplicity')
        vals.append({'m':m,'H_exact':str(H),'H_decimal':str(s.N(H,16))})
    models.append({'nonreal_pair_multiplicity':mult,'values':vals})
# Integer cutoff algebra: L=9n log2 makes the outer tail rational.
for n in range(1,41):
    assert Q(20*n)*Q(8)**(2*n-1)/Q(2)**(6*n)==Q(5*n,2)
    assert n**8 <= 2**(9*n)
    checks['integer window and outer-tail normalization']+=2
print('Exact checks complete',sum(checks.values()),flush=True)
# Source-derived scalar diagonal sequence. No zero or root solver is used.
_,ss,_=old.shifted_theta_coefficients(84)
theta=[]
for m in [0,1,2,3,4,6,8,12,16,20,24,28,32,36,40]:
    P=s.expand((y-2)*V(m,2*y/b-1))
    H=form_square(P,ss)
    norm=Q(1664,2187) if m==0 else Q(1408,729)
    assert H.lo>0,(m,H.out())
    checks['actual theta positive diagonal under fresh Arb source intervals']+=1
    theta.append({'m':m,'test_degree':m+1,'N_exact':str(norm),'H':ivout(H),'H_over_N':ivout(H/norm)})
    print('theta',m,dec_bounds(H,18),flush=True)
# Fresh ordinary-prime calculation for P=y-2, independently from arithmetic.
P=y-2;wc=coeff(W_from_square(P),l)
X=65536;ps=old.primes_to(X);prefix=IV(0)
from prime_dyadic import prime_form
lo,hi=prime_form(ps,wc).frac()
prefix=IV(lo,hi)
print('ordinary prime prefix complete',len(ps),flush=True)
# For each log-monomial, theta(t)<=4t and decreasing x^-2 log^j x give
# tail <=4*(log(X)^j/X + int_X^infty x^-2 log(x)^j dx).
lx=16*old.LOG2;radius=IV(0)
for j,w in enumerate(wc):
    assert lx.lo>Q(j,2)
    Ij=old.tail_integral(j,lx,X)
    radius+=4*abs(w)*(lx**j/Q(X)+Ij)
# A sharper one-sided tail retains the cubic sign and cancellation.
Wexpr=W_from_square(P)
# W>0 and 2W-W'>0 for ell>=8, by their displayed shifted coefficients.
tmp=s.Symbol('t', nonnegative=True)
assert all(v>=0 for v in s.Poly(Wexpr.subs(l,tmp+8),tmp).all_coeffs())
assert all(v>=0 for v in s.Poly((2*Wexpr-s.diff(Wexpr,l)).subs(l,tmp+8),tmp).all_coeffs())
assert lx.lo>8
signed_radius=4*(old.eval_poly(wc,lx)/Q(X)+sum((w*old.tail_integral(j,lx,X) for j,w in enumerate(wc)),IV(0)))
assert signed_radius.lo>0 and signed_radius.hi<radius.hi
full=prefix+IV(0,signed_radius.hi)
assert full.hi<0
checks['signed monotone ordinary-tail improvements']+=3
checks['independent infinite ordinary-prime sign with full tail']+=1
print('ordinary full',dec_bounds(full,15),'radius',dec_bounds(radius,15),flush=True)
res={'scope':'Written all-order proofs separate from finite checks. Theta rows use fresh source-only Arb quadrature intervals. Ordinary-prime full sign independently summed from primes with analytic all-prime tail.',
     'RH_PROOF':False,'checks':dict(checks),'total_assertions':sum(checks.values()),'models':models,'theta_diagonal_tests':theta,
     'ordinary_prime':{'P':'y-2','cutoff':X,'prime_count':len(ps),'prefix':ivout(prefix),'absolute_tail_allowance':ivout(radius),'signed_positive_tail_allowance':ivout(signed_radius),'full_enclosure':ivout(full)},
     'source_sha256':hashlib.sha256((BASE/'inputs/fresh_moments_0_88.json').read_bytes()).hexdigest(),'runtime_seconds':time.time()-start}
(OUT/'final_checks.json').write_text(json.dumps(res,indent=2))
print('PASS',sum(checks.values()),'seconds',time.time()-start,flush=True)
