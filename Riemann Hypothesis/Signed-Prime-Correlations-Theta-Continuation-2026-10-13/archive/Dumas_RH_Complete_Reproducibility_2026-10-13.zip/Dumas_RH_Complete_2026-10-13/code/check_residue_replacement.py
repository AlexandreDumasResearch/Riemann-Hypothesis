#!/usr/bin/env python3
"""Exact algebra checks only; no statement about actual theta-zero locations."""
import json
from pathlib import Path
import sympy as s
w,z=s.symbols('w z')
checks=[]
for M in (2,3,4):
    r=M+4
    gamma=s.Integer(100)
    delta=s.Rational(1,4)
    ordinates=[gamma+s.Rational(2*j-r+1,200) for j in range(r)]
    D=s.prod(w*w-l*l for l in ordinates)
    G=w**(2*M+2)*(w*w+s.Rational(1,4))
    z0=gamma+s.I*delta
    R=s.expand_complex(D.subs(w,z0)/G.subs(w,z0)).expand()
    a=s.im(R)/(2*gamma*delta)
    b=s.re(R)-a*(gamma**2-delta**2)
    Q=s.Poly(D-G*(a*w*w+b),w)
    assertions={
        'real_coefficients': all(s.im(c)==0 for c in Q.all_coeffs()),
        'prescribed_nonreal_zero': s.cancel(Q.eval(z0))==0,
        'endpoint_normalization': s.cancel(Q.eval(s.I/2)-D.subs(w,s.I/2))==0,
        'vanishing_finite_jet': all(s.Poly(Q.as_expr()-D,w).nth(k)==0 for k in range(2*M+2)),
        'degree_unchanged': Q.degree()==2*r,
        'multiplier_proper': s.degree(Q.as_expr()-D,w)<=2*r-2,
    }
    P=z**r-s.re((s.I*delta)**r)-z/delta*s.im((s.I*delta)**r)
    assertions['limit_simple_roots']=s.discriminant(P,z)!=0
    assertions['limit_prescribed_pair']=s.expand(P.subs(z,s.I*delta))==0
    assertions={key:bool(value) for key,value in assertions.items()}
    assert all(assertions.values()),(M,assertions)
    checks.append({'M':M,'r':r,'checks':assertions,'limit_factorization':str(s.factor(P))})
out={'scope':'Exact rational polynomial identities; illustrative ordinates are not xi zeros. No numerical RH certificate.','checks':checks,'all_pass':True}
p=Path(__file__).resolve().parents[1]/'results'/('residue_replacement_checks.json')
p.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
