"""Independent positive-logarithm / prime summation on a fixed dyadic grid.
All elementary operations enclose their mathematical operands by integer floor
and ceiling. No library logarithm, zeta zero, or theta coefficient is used.
"""
from __future__ import annotations
from fractions import Fraction
D=1<<112

def ceildiv(a:int,b:int)->int:
    assert b>0
    return -((-a)//b)

class DI:
    __slots__=('lo','hi')
    def __init__(self,lo:int,hi:int):
        assert lo<=hi
        self.lo,self.hi=lo,hi
    @staticmethod
    def q(x):
        x=Fraction(x)
        return DI(x.numerator*D//x.denominator,ceildiv(x.numerator*D,x.denominator))
    def __add__(self,b):
        if not isinstance(b,DI):b=DI.q(b)
        return DI(self.lo+b.lo,self.hi+b.hi)
    __radd__=__add__
    def __neg__(self):return DI(-self.hi,-self.lo)
    def __mul__(self,b):
        if not isinstance(b,DI):b=DI.q(b)
        v=(self.lo*b.lo,self.lo*b.hi,self.hi*b.lo,self.hi*b.hi)
        return DI(min(v)//D,ceildiv(max(v),D))
    __rmul__=__mul__
    def divint(self,k):
        assert k>0
        return DI(self.lo//k,ceildiv(self.hi,k))
    def frac(self):return Fraction(self.lo,D),Fraction(self.hi,D)

def logunit(num:int,den:int,terms:int=28):
    assert den<=num<=2*den
    y=DI.q(Fraction(num-den,num+den)); y2=y*y;power=y;out=DI.q(0)
    for j in range(terms):
        out=out+(2*power).divint(2*j+1)
        power=power*y2
    # remainder <= 2*y^(2M+1) / ((2M+1)*(1-y^2)).
    rem=ceildiv(2*power.hi*D,(2*terms+1)*(D-y2.hi))
    return DI(out.lo,out.hi+rem)
LOG2=logunit(2,1,40)

def logint(n:int):
    assert n>=1
    e=n.bit_length()-1
    return e*LOG2+logunit(n,1<<e)

def prime_form(primes,coeffs):
    acc=DI.q(0);cc=[DI.q(c) for c in coeffs]
    for p in primes:
        lp=logint(p);val=DI.q(0)
        for v in reversed(cc):val=val*lp+v
        acc=acc+(lp*val).divint(p*p)
    return acc
