"""Rational arithmetic kernels and rigorously bounded source-series shift.

The shift tail uses the analytically stated source moment majorant
mu_k <= (1/2)_k / 9^k, in addition to the freshly computed finite moments.
"""
from __future__ import annotations
import math
from fractions import Fraction as Q
import sympy as sp
from intervals import IV, J, poch, dec_bounds

def q(v):
    v=sp.Rational(v)
    return Q(int(v.p),int(v.q))


def log_unit(v: Q, terms: int=140) -> IV:
    """Rigorous log(v) for 1 <= v <= 4 using the atanh expansion."""
    assert 1 <= v <= 4
    y=IV((v-1)/(v+1)); y2=y*y; power=y; acc=IV(0)
    for k in range(terms):
        acc += 2*power/Q(2*k+1)
        power *= y2
    # all omitted terms are positive; the denominator only grows
    rem=2*power/(Q(2*terms+1)*(1-y2))
    return acc+IV(0,rem.hi)

LOG2=log_unit(Q(2))


def log_integer(v: int) -> IV:
    assert v >= 1
    e=v.bit_length()-1
    return e*LOG2+log_unit(Q(v,2**e),90)



def shifted_theta_coefficients(N):
    """F(z-a)/F(-a), a=9/16. All shift terms have known common sign.
    Tail from |f_m| <= 1/(9^m m!), with all m>88 retained by a bound.
    """
    a=Q(9,16); B=[]
    for k in range(N+1):
        b=sum((J[m]*a**(m-k)/Q(poch(m)*math.factorial(k)*math.factorial(m-k))
               for m in range(k,89)),IV(0))
        R=89-k
        first=Q(1,9**k*math.factorial(k))*Q(1,16)**R/Q(math.factorial(R))
        ratio=Q(1,16*(R+1))
        b+=IV(0,first/(1-ratio))
        B.append(b)
    f=[(-1)**k*B[k]/B[0] for k in range(N+1)];f[0]=IV(1)
    s=[IV(0)]
    for k in range(1,N+1):
        s.append(-k*f[k]-sum((s[j]*f[k-j] for j in range(1,k)),IV(0)))
    return f,s,B[0]



def p_bessel(k,L,r=sp.Rational(3,2)):
    return sp.expand(2**(k+1)/(sp.factorial(k)*r**(k+1))*sum(
        sp.factorial(k+j)*L**(k-j)/(sp.factorial(j)*sp.factorial(k-j)*(2*r)**j)
        for j in range(k+1)))


def eval_poly(coeffs,x):
    a=IV(0)
    for c in reversed(coeffs):a=a*x+c
    return a


def monomial_integral(coeffs):
    return sum((c*math.factorial(k) for k,c in enumerate(coeffs)),Q(0))


def tail_integral(j: int, logX: IV, X: int) -> IV:
    """int_X^infinity x^-2 (log x)^j dx, exact incomplete-gamma formula."""
    return Q(math.factorial(j),X)*sum((logX**k/Q(math.factorial(k)) for k in range(j+1)),IV(0))


def primes_to(X):
    sieve=bytearray(b'\x01')*(X+1);sieve[0:2]=b'\x00\x00'
    for p in range(2,math.isqrt(X)+1):
        if sieve[p]:sieve[p*p:X+1:p]=b'\x00'*(((X-p*p)//p)+1)
    return [p for p in range(2,X+1) if sieve[p]]


def out_iv(x,places=45):
    return {'rational':x.out(),'decimal':dec_bounds(x,places)}


