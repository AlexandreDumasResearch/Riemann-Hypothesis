#!/usr/bin/env python3
"""Deterministic appendix audits. Algebraic checks are exact where indicated.
Numerical outputs are diagnostics, never substitutes for the manuscript proofs.
"""
import json
import math
from pathlib import Path
import sympy as sp

results = {}
# Exact rational replacement identity, after reduction by its defining equation.
w, u, d, l1, l2 = sp.symbols('w u d l1 l2', real=True)
c = sp.Rational(1,4)
A = 2*u-2*d-l1-l2
D = (w*w-l1)*(w*w-l2)
Q = w**4-2*(u-d)*w*w+(u+d)**2
constraint = (u+d+c)**2-(l1+c)*(l2+c)-d
assert sp.expand(Q-D+A*(w*w+c)-constraint) == 0
results['replacement_polynomial_identity'] = 'exact PASS'
# A changed denominator changes both its Schur complement and its source.
mat=sp.Matrix([[2,1],[1,2]])
short=mat[0,0]-mat[0,1]**2/mat[1,1]
source=1-mat[0,1]/mat[1,1]
assert short==sp.Rational(3,2) and source**2/short==sp.Rational(1,6)
results['background_counterexample']={'short':str(short),'source':str(source),'cost':str(source**2/short)}
# Reference-relative identity, including a signed perturbation.
H=sp.Matrix([[7,1,2],[1,8,1],[2,1,9]])
V=sp.Matrix([[-3,2,-1],[2,-1,1],[-1,1,-2]])
C=H[:1,1:]; Q0=H[1:,1:]; T=Q0.inv()*C.T
Vof=V[:1,1:]; Vff=V[1:,1:]; den=Q0+Vff
SH=H[:1,:1]-C*Q0.inv()*C.T
E=Vof-T.T*Vff
W=V[:1,:1]-Vof*T-T.T*Vof.T+T.T*Vff*T
full=H+V
rhs=SH+W-E*den.inv()*E.T
lhs=full[:1,:1]-full[:1,1:]*den.inv()*full[1:,:1]
assert rhs==lhs
results['reference_relative_schur_identity']='exact PASS'
# Exact all-integer geometric checks underlying collar coisometry.
for n in range(2,301):
    for q in range(2,n+1):
        assert not (n<q*q<n+1)
        # Image lies in (0, a_n), up to null endpoints:
        assert q*q*n >= n+1 and q<=n
    # Same-orientation gaps exceed half the canonical log gap.
    assert n*n*n > (n+1)*(n-1)*(n-1)
results['collar_integer_geometry']='PASS n=2,...,300'
# The adversarial one-scale source has identically zero packet masses.
for q in (4,6,8):
    for j in range(1,101):
        length=(j+1)**q-j**q
        assert length%2==1
        h=(length-1)//2
        assert h-h==0
results['single_scale_counterexample']={str(q):{'packet_mass':0,'pole':str(1-sp.Rational(1,q)),'residue':str(sp.Rational(q-1,4))} for q in (4,6,8)}
# Improved detector rates and a cutoff with positive error margin.
rates=[]
for delta in (.01,.1,.25,.49):
    eta=.999*delta*delta
    rate=(1-math.sqrt(1-4*eta))/2
    cc=.9*rate
    lo=1+math.sqrt(1-4*eta)
    hi=2*eta/cc
    tau=(2*lo+hi)/3; L=(lo+2*hi)/3
    alpha=tau*tau/4-tau/2
    assert alpha+eta>0 and 2*eta/L>cc
    rates.append({'delta':delta,'old_threshold':delta*delta/4,'new_threshold':(1-math.sqrt(1-4*delta*delta))/2,'cutoff_margin':alpha+eta})
results['detector_rates']=rates
# Integrate the fixed-b essential-norm lower bound exactly on its step cells.
a=1.0
limit=math.sqrt(2*math.sinh(a))
growth=[]
for b in (4.,6.,8.,10.):
    primes=list(sp.primerange(2,math.floor(math.exp(a+b))+1))
    lp=[math.log(p) for p in primes]
    ww=[(1-1/p)*math.log(p) for p in primes]
    pref=[0.0]
    for v in ww: pref.append(pref[-1]+v)
    import bisect
    def Glog(z): return pref[bisect.bisect_right(lp,z)]
    cuts={0.0,a}
    for z in lp:
        for x in (b-z,a-z,z-b,z-a):
            if 0<x<a: cuts.add(x)
    cuts=sorted(cuts)
    integral=0.0
    for left,right in zip(cuts,cuts[1:]):
        x=(left+right)/2
        aa=Glog(b-x)-Glog(a-x)
        dd=Glog(b+x)-Glog(a+x)
        integral+=aa*aa*(math.exp(right)-math.exp(left))+dd*dd*(math.exp(-left)-math.exp(-right))
    integral/=(math.exp(b)-math.exp(a))
    growth.append({'b':b,'scaled_lower_bound':math.exp(-b/2)*math.sqrt(integral),'PNT_limit':limit})
results['essential_growth_diagnostic']=growth
out=Path(__file__).resolve().parents[1]/'results'/'appendix_v2.json'
out.write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
