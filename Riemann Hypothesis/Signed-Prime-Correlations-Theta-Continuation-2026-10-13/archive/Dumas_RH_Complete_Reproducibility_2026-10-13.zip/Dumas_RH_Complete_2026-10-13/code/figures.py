"""Reproduce publication vector figures. Kernel curves use floating evaluation.
The certificate plot reads validated rational endpoints; it does not add tests.
"""
from pathlib import Path
from fractions import Fraction
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.special import eval_laguerre

BASE=Path(__file__).resolve().parent.parent
OUT=BASE/'figures'; OUT.mkdir(exist_ok=True)
plt.rcParams.update({'font.family':'STIXGeneral','mathtext.fontset':'stix',
    'font.size':11,'axes.labelsize':11,'axes.titlesize':11,'legend.fontsize':9,
    'xtick.labelsize':9,'ytick.labelsize':9,'pdf.fonttype':42,'ps.fonttype':42,
    'axes.spines.top':False,'axes.spines.right':False,'axes.linewidth':0.6,
    'savefig.pad_inches':0.04})
NAVY='#183c5a'; TEAL='#007e86'; ORANGE='#be6e20'; LIGHT='#eaf2f4'
rows=json.loads((BASE/'results'/'final_checks.json').read_text())['theta_diagonal_tests']
ms=np.array([r['m'] for r in rows])
vals=[];errs=[]
for r in rows:
    lo,hi=map(Fraction,r['H_over_N']['rational'])
    vals.append(float((lo+hi)/2)); errs.append(float((hi-lo)/2))
fig,ax=plt.subplots(figsize=(6.8,3.05),layout='constrained')
ax.axhline(0,color='#a7b1b9',lw=.7)
ax.vlines(ms,0,vals,color='#c7d9df',lw=1)
ax.errorbar(ms,vals,yerr=errs,fmt='o',markersize=5,color=NAVY,ecolor=TEAL,capsize=2,lw=1)
ax.set(xlabel='Diagonal index $m$',ylabel=r'$h_m/\mathcal{N}[P_m]$',xlim=(-1,41),ylim=(-.008,.22))
ax.set_xticks(np.arange(0,41,4));ax.set_yticks(np.arange(0,.21,.05))
ax.grid(axis='y',lw=.45,color='#e3e8eb')
ax.text(.03,.96,'Fifteen source-derived interval certificates',transform=ax.transAxes,va='top',color=NAVY)
ax.text(.03,.86,'Interval widths are smaller than the markers.',transform=ax.transAxes,va='top',fontsize=9,color='#5c6873')
fig.savefig(OUT/'certificate_diagonal.pdf');fig.savefig(OUT/'certificate_diagonal.png',dpi=180)
plt.close(fig)

# q_m(l)=exp(-3l/2)W_m(l). This evaluation is illustrative, not a certificate.
def Lscr(k,l):
    if k==0:return np.ones_like(l)
    return (-1)**k*.5*(eval_laguerre(k,3*l)-eval_laguerre(k-1,3*l))
def qnorm(m,l):
    fixed=132*Lscr(0,l)-160*Lscr(1,l)+32*Lscr(2,l)
    band=16*Lscr(2*m-1,l)-80*Lscr(2*m,l)+132*Lscr(2*m+1,l)-80*Lscr(2*m+2,l)+16*Lscr(2*m+3,l)
    return np.exp(-1.5*l)*(32/2187)*(fixed+band)/(1408/729)
fig,axes=plt.subplots(1,2,figsize=(7.1,3.2),layout='constrained',gridspec_kw={'width_ratios':[1.08,1]})
ax=axes[0];ell=np.linspace(0,10,1601)
for m,col in [(2,NAVY),(8,TEAL),(32,ORANGE)]:ax.plot(ell,qnorm(m,ell),color=col,lw=1.1,label=f'$m={m}$')
ax.axhline(0,color='#929da5',lw=.65);ax.set(xlim=(0,10),ylim=(-.42,1.06),xlabel=r'$\ell=\log x$',ylabel=r'$q_{P_m}(\ell)/\mathcal{N}[P_m]$')
ax.set_title('(a) The signed sampling kernel',loc='left',pad=8);ax.legend(frameon=False,ncol=3,handlelength=1.2,columnspacing=.7,loc='upper right')
ax.grid(axis='y',lw=.4,color='#e3e8eb')
ax=axes[1];n=np.geomspace(3,200,500)
old=(1408/729)*(8*n**4+18.5*n+38+.5*np.log(n+1))
new=(1408/729)*(16*n+38+.5*np.log(n+1))+1/3
ax.loglog(n,old,color=ORANGE,lw=1.4,label='Middle sum: $E_n$')
ax.loglog(n,new,color=TEAL,lw=1.4,label='Complete prefix: $F_n$')
ax.set(xlim=(3,200),xlabel=r'Containing degree $n=m+2$',ylabel='Proved allowance')
ax.set_title('(b) The two finite-prime allowances',loc='left',pad=8)
ax.legend(frameon=False,loc='upper left');ax.grid(which='major',lw=.4,color='#e3e8eb')
fig.savefig(OUT/'signed_kernel_and_windows.pdf');fig.savefig(OUT/'signed_kernel_and_windows.png',dpi=180)
plt.close(fig)

# Table includes outward-rounded decimal intervals, not rounded midpoints.
lines=['m,degree,H_lower,H_upper,H_over_N_lower,H_over_N_upper']
for r in rows:lines.append(','.join(map(str,[r['m'],r['test_degree'],*r['H']['decimal'],*r['H_over_N']['decimal']])))
(BASE/'results'/'diagonal_table.csv').write_text('\n'.join(lines)+'\n')
