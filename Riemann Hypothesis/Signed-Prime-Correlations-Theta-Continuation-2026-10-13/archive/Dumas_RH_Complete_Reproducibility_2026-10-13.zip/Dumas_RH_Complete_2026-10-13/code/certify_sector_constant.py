"""Outward rational enclosure of the new sector constant.

Uses the previously validated complete-source moment enclosures supplied here;
does not rerun their quadrature. The ordinary-prime prefix is freshly summed
with dyadic log intervals, and its complete infinite tail is bounded analytically.
"""
import hashlib
import json
from fractions import Fraction as Q
from pathlib import Path
from intervals import IV, dec_bounds
import arithmetic as ar
from prime_dyadic import prime_form

assert __debug__, 'Assertions are required: do not use Python -O.'
BASE=Path(__file__).resolve().parents[1]
_, ss, _=ar.shifted_theta_coefficients(3)
Cxi=Q(16,9)*(4*ss[1]-4*ss[2]+ss[3])
coeff=[Q(1408,729),-Q(1024,243),Q(256,243)]
X=65536
primes=ar.primes_to(X)
lo,hi=prime_form(primes,coeff).frac()
prefix=IV(lo,hi)
lx=16*ar.LOG2
# For every j<=2, log^j(x)/x^2 is decreasing for x>=X.
# theta(x)<=4x and partial summation yield this conservative all-prime tail.
radius=IV(0)
for j,c in enumerate(coeff):
    assert 2*lx.lo>j
    radius+=4*abs(c)*(lx**j/Q(X)+ar.tail_integral(j,lx,X))
tinf=prefix+IV(-radius.hi,radius.hi)
kappa=Cxi/2+tinf-Q(128,6561)
assert Cxi.lo>0 and kappa.hi<0
def enc(v):return {'exact_rational_endpoints':v.out(),'outward_decimal':dec_bounds(v,18)}
data={
 'status':'PASS',
 'scope':'Exact interval propagation from supplied v2 moments; newly summed prime prefix with a complete analytic tail. No RH assumption.',
 'moment_input_sha256':hashlib.sha256((BASE/'inputs/fresh_moments_0_88.json').read_bytes()).hexdigest(),
 'prime_cutoff':X,'prime_count':len(primes),
 'shifted_log_coefficients':[enc(v) for v in ss[1:4]],
 'C_xi':enc(Cxi),'t_infinity_prefix':enc(prefix),
 't_infinity_absolute_tail_radius':enc(radius),'t_infinity':enc(tinf),
 'square_boundary_anomaly':'128/6561','kappa':enc(kappa),
 'kappa_strictly_negative':True,
 'consequence_scope':'RH implies U_m <= kappa+o(1), hence eventually negative; this does not establish RH.'
}
(BASE/'results').mkdir(exist_ok=True)
(BASE/'results/sector_constant_certificate.json').write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps({'status':data['status'],'prime_count':len(primes),'Cxi':dec_bounds(Cxi,18),'t_infinity':dec_bounds(tinf,18),'kappa':dec_bounds(kappa,18)},indent=2))
