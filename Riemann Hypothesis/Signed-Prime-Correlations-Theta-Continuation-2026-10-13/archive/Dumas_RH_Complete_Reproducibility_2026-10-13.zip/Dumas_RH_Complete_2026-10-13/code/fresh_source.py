"""Fresh complete-theta moments, computed from source only with Arb ball arithmetic.

The quadrature/error formulas are documented in QUADRATURE.md. Approximate
Legendre roots propose brackets only; all acceptance is in Arb. No historical
moment, xi zero, or RH assumption is an input. No checkpoint is loaded.
"""
from pathlib import Path
from fractions import Fraction
import json, time, hashlib, argparse
import mpmath as mp
from flint import arb, fmpq, ctx

BASE=Path(__file__).resolve().parent.parent
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--cross-check',action='store_true',help='reconstruct with 48 cells, 128 nodes, 10 modes and 1000 bits, then check interval intersections')
args=parser.parse_args()
DEGREE=88
CELLS,ORDER,MODES,BITS,BRACKET,DECIMALS=(48,128,10,1000,200,330) if args.cross_check else (32,120,8,850,160,280)
ctx.prec=BITS; mp.mp.dps=DECIMALS
A=arb
R=A(1)/4

def exact(x):
    x=Fraction(x)
    return A(fmpq(x.numerator,x.denominator))

def legendre(n,x):
    a=x*0+1; b=x
    if n==0:return a,x*0
    for j in range(1,n):a,b=b,((2*j+1)*x*b-j*a)/(j+1)
    return b,a

def nodes_weights():
    nodes=[]; weights=[]; brackets=[]
    D=10**(BRACKET+20); pad=10**20 # exact rational radius
    for j in range(ORDER,0,-1):
        x=mp.cos(mp.pi*(j-mp.mpf('.25'))/(ORDER+mp.mpf('.5')))
        for _ in range(30):
            p,prev=legendre(ORDER,x)
            dp=ORDER*(prev-x*p)/(1-x*x)
            delta=p/dp; x-=delta
            if abs(delta)<mp.mpf(10)**(-DECIMALS+20):break
        num=int(mp.floor(x*D)); lo=Fraction(num-pad,D); hi=Fraction(num+pad,D)
        left,right=exact(lo),exact(hi)
        pl,_=legendre(ORDER,left); pr,_=legendre(ORDER,right)
        assert (pl<0 and pr>0) or (pl>0 and pr<0)
        assert left>-1 and right<1
        if brackets: assert brackets[-1][1]<lo
        brackets.append((lo,hi))
        v=A(exact((lo+hi)/2),exact((hi-lo)/2))
        p,prev=legendre(ORDER,v)
        dp=ORDER*(prev-v*p)/(1-v*v)
        w=2/((1-v*v)*dp*dp)
        assert w>0
        nodes.append(v); weights.append(w)
    assert sum(weights,A(0)).contains(2)
    return nodes,weights,brackets

def phi(u):
    eu=(2*u).exp(); X=A.pi()*eu; total=A(0)
    for j in range(1,MODES+1):
        Y=X*j*j
        total+=(u/2-Y).exp()*(8*Y*Y-12*Y)
    j=MODES+1; Y=X*j*j
    ratio=A(j+1)**4/A(j)**4*(-X*(2*j+1)).exp()
    assert ratio<1
    rem=(u/2-Y).exp()*(8*Y*Y+12*Y)/(1-ratio)
    return total+A(0,rem.upper())

def disk_bound(c):
    xmax=A.pi()*(2*(c+R)).exp()
    b=A.pi()*(2*(c-R)).exp()*(2*R).cos()
    assert b>0
    total=A(0)
    for j in range(1,MODES+1):
        y=xmax*j*j
        total+=(8*y*y+12*y)*(-b*j*j).exp()
    j=MODES+1; y=xmax*j*j
    ratio=A(j+1)**4/A(j)**4*(-b*(2*j+1)).exp()
    assert ratio<1
    total+=(8*y*y+12*y)*(-b*j*j).exp()/(1-ratio)
    return ((c+R)/2).exp()*total

def raw_bound(x):
    # arb.lower/upper return exact dyadic endpoints (display itself is rounded).
    def encode(endpoint):
        man,exp=endpoint.man_exp(); man,exp=int(man),int(exp)
        return [int(man<0),abs(man),exp,abs(man).bit_length()]
    return [encode(x.lower()),encode(x.upper())]

def decimal_bounds(x):
    return [str(x.lower()),str(x.upper())]

def main():
    started=time.time(); nodes,weights,brackets=nodes_weights()
    moments=[A(0) for _ in range(DEGREE+1)]
    errors=[A(0) for _ in range(DEGREE+1)]
    for ci in range(CELLS):
        c=A(4*(2*ci+1))/(2*CELLS); h=A(2)/CELLS
        B=disk_bound(c); ratio=h/R
        err=4*h*ratio**(2*ORDER)/(1-ratio)*B
        cm=(c+R)**2
        for k in range(DEGREE+1): errors[k]+=err; err*=cm
        for x,w in zip(nodes,weights):
            u=c+h*x; term=h*w*phi(u); u2=u*u
            for k in range(DEGREE+1): moments[k]+=term; term*=u2
        if (ci+1)%8==0: print('complete theta cells',ci+1,flush=True)
    A0=A.pi()*A(8).exp()
    assert 16*(-3*A0).exp()<A(1)/2
    tails=[]
    for k in range(DEGREE+1):
        rate=2*A0-A(9)/2-A(k)/2
        assert rate>0
        tail=40*A(16)**k*A(2).exp()*A0*A0*(-A0).exp()/rate
        tails.append(tail)
        # spatial tail is nonnegative; symmetric enlargement is conservative.
        moments[k]+=A(0,(errors[k]+tail).upper())
        assert moments[k]>0
    dest=BASE/'inputs'/('crosscheck_moments_0_88.json' if args.cross_check else 'fresh_moments_0_88.json')
    result={'scope':'Fresh source-only Arb ball quadrature; no inherited moments, no zero seeds. Mathematical enclosure relies on the explicitly stated analytic quadrature bounds and Arb arithmetic.',
       'source_moments':[raw_bound(x) for x in moments], 'through_order':DEGREE,
       'quadrature':{'cells':CELLS,'order':ORDER,'nodes':CELLS*ORDER,'explicit_modes':MODES,'arb_precision_bits':BITS,'radius':'1/4','node_bracket_radius':f'1e-{BRACKET}','all_gauss_brackets_validated':True,'full_mode_and_spatial_tails_paid':True},
       'engine_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    dest.write_text(json.dumps(result,indent=2))
    def frac(raw):
        sign,man,exp,_=raw
        return (-1)**sign*Fraction(man)*Fraction(2)**exp
    widths=[]
    for lo,hi in result['source_moments']:
        low,high=frac(lo),frac(hi)
        widths.append(float((high-low)/((high+low)/2)))
    summary={'source_sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),
      'max_relative_interval_width':max(widths),
      'quadrature':result['quadrature'],
      'runtime_seconds':time.time()-started}
    comparison=[]
    if args.cross_check:
        primary=json.loads((BASE/'inputs'/'fresh_moments_0_88.json').read_text())['source_moments']
        for k,((a,b),(c,d)) in enumerate(zip(primary,result['source_moments'])):
            alo,ahi,clo,chi=map(frac,(a,b,c,d))
            assert max(alo,clo)<=min(ahi,chi), ('disjoint source enclosures',k)
            comparison.append({'k':k,'nonempty_intersection':True,'crosscheck_subset':alo<=clo<=chi<=ahi})
        summary['comparison']=comparison
        summary['comparison_scope']='Independent regeneration with changed nodes, cells, mode count and precision; shared analytic enclosure method and Arb library.'
    (BASE/'results'/('source_crosscheck_summary.json' if args.cross_check else 'fresh_source_summary.json')).write_text(json.dumps(summary,indent=2))
    print(json.dumps(summary,indent=2))

if __name__=='__main__':main()
