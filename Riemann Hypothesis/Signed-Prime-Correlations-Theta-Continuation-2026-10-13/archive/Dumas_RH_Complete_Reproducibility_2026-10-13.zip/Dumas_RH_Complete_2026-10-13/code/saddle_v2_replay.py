#!/usr/bin/env python3
"""Independent saddle normalization/cubic replay and NON-VALIDATED diagnostics.

The symbolic assertions are exact. Numerical quadrature below uses complete-source
modes with an explicit uniform omitted-mode bound on the quadrature rectangle.
It does NOT bound the floating-point quadrature error or the full exterior
integral; it is therefore never a numerical positivity certificate. The complete
analytic tail proof is in source/saddle.tex.
"""
from pathlib import Path
import json
import numpy as np
import sympy as sp
from scipy.special import lambertw
from numpy.polynomial.legendre import leggauss


def symbolic_replay():
    c,D,u,v,r,tau,y=sp.symbols('c D u v r tau y', real=True, nonzero=True)
    n=D/(4*c*c)
    phase=(2*n*sp.log(1+c*v/D)+9*c*v+4*tau*D*c*v
        +2*tau*c*c*(v*v+u*u)+4*sp.I*tau*y*c*u
        -n/D*(sp.exp(2*c*v)*sp.cosh(2*c*u)-1)
        -sp.I*n/D*r*(sp.exp(2*c*v)*sp.sinh(2*c*u)-2*c*u))
    Q=-u*u/2-(1+1/(2*D))*v*v/2-sp.I*r*u*v
    odd=c*((9+4*tau*D)*v+4*sp.I*tau*y*u
        -(sp.Rational(1,3)-1/(6*D*D))*v**3-v*u*u
        -sp.I*r*(u*v*v+u**3/3))
    series=sp.series(phase,c,0,2).removeO()
    assert sp.simplify(series-Q-odd)==0
    assert sp.simplify(odd.xreplace({u:-u,v:-v})+odd)==0
    assert sp.simplify(Q.xreplace({u:-u,v:-v})-Q)==0
    det=sp.Matrix([[1,sp.I*r],[sp.I*r,1+1/(2*D)]]).det()
    assert sp.simplify(det-(1+r*r+1/(2*D)))==0
    return {'quadratic_and_cubic':'exact symbolic pass', 'odd_cancellation':'exact symbolic pass',
            'mixed_determinant':'exact symbolic pass'}


def diagnostic(n,C,tau,order=200,U=10.0,J=6):
    D=float(lambertw(n/(np.pi*C)).real)/2
    c=np.sqrt(D/(4*n)); y=np.arccos(C)/2; r=np.tan(2*y)
    nodes,weights=leggauss(order); v=U*nodes[:,None]; u=U*nodes[None,:]
    wt=U*U*weights[:,None]*weights[None,:]
    phase=(2*n*np.log1p(c*v/D)+9*c*v+4*tau*D*c*v
           +2*tau*c*c*(v*v+u*u)+4j*tau*y*c*u
           -n/D*(np.exp(2*c*v)*np.cosh(2*c*u)-1)
           -1j*n/D*r*(np.exp(2*c*v)*np.sinh(2*c*u)-2*c*u))
    def multiplier(z):
        out=np.zeros(z.shape,dtype=complex)
        for j in range(1,J+1):
            out+=(j**4-3/(2*np.pi)*j*j*np.exp(-2*z))*np.exp(-np.pi*(j*j-1)*np.exp(2*z))
        return out
    z1=D+c*(v+u)+1j*y; z2=D+c*(v-u)-1j*y
    value=np.sum(wt*np.exp(phase)*multiplier(z1)*multiplier(z2))
    main=2*np.pi*C/np.sqrt(1+C*C/(2*D))
    rmin=D-2*c*U
    assert rmin>0
    tmin=np.pi*C*np.exp(2*rmin)
    rho=((J+2)/(J+1))**4*np.exp(-tmin*(2*J+3))
    logtail=(4*np.log(J+1)-tmin*((J+1)**2-1)-np.log1p(-rho)
        +np.log1p(3/(2*np.pi)*np.exp(-2*rmin)/(J+1)**2))
    return {'n':n,'C':C,'tau':tau,'order':order,'scaled_cutoff':U,'modes':J,'D':D,
        'normalized_real_diagnostic':float(value.real),'imaginary_residual':float(value.imag),
        'gaussian_main':float(main),'relative_difference':float(value.real/main-1),
        'log_uniform_omitted_source_multiplier_bound':float(logtail),
        'status':'diagnostic only; quadrature and exterior not numerically validated'}

if __name__=='__main__':
    out={'symbolic':symbolic_replay(), 'diagnostics':[
        diagnostic(n,C,tau) for n in (1000,10000) for C in (1.0,0.8,0.4)
        for tau in (0.0,-0.1,0.1)]}
    target=Path(__file__).resolve().parents[1]/'results'/'saddle_v2_replay.json'
    target.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({'symbolic':out['symbolic'],'diagnostic_rows':len(out['diagnostics']),
        'max_abs_imaginary':max(abs(r['imaginary_residual']) for r in out['diagnostics']),
        'output':str(target)},indent=2))
