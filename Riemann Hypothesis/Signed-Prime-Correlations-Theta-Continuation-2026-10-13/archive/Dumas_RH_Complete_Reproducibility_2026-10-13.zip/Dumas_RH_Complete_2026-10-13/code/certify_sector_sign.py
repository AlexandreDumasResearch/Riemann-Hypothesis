"""Rigorous Arb enclosure for kappa; analytic full ordinary-prime tail.

Requires python-flint==0.9.0 and sympy==1.14.0. The finite cutoff is 10000;
no large moving prime prefix is enumerated. All Arb operations are ball
operations. Exact rational output endpoints are included for portability.
"""
from flint import arb, arb_series, ctx
from sympy import primerange
import flint, sympy
import json
ctx.prec=192
ctx.cap=4
z=arb_series([0,1])
s=arb_series([arb(1)/2])+(arb_series([arb(9)/4])-4*z).sqrt()
xi=s*(s-1)*(s/2).gamma()*s.zeta()*(-s*arb.pi().log()/2).exp()/2
logxi=xi.log()
hat_s=[-j*logxi[j] for j in range(1,4)]
Cxi=arb(16)/9*(4*hat_s[0]-4*hat_s[1]+hat_s[2])
X=10000
prime_list=list(primerange(2,X+1))
t_part=arb(0)
a=arb(256)/243
for p in prime_list:
    lp=arb(p).log()
    poly=a*(lp*lp-4*lp+arb(11)/6)
    t_part +=lp*poly/(p*p)
L=arb(X).log()
# For ell>=L>8, P(ell)>0 and 2P-P'>0. Partial summation
# and theta(x)<=4x give 0<=tail<=4*a/X*(2L^2-6L+5/3).
assert L>8
prime_tail_upper=4*a/X*(2*L*L-6*L+arb(5)/3)
kappa_lower=(Cxi/2+t_part-arb(128)/6561).lower()
kappa_upper=(Cxi/2+t_part+prime_tail_upper-arb(128)/6561).upper()
assert kappa_lower > -arb(14)/100
assert kappa_upper < -arb(8)/100
assert 36**41 <506**13*5**41
out={
 "status":"rigorous Arb ball enclosure plus proved analytic prime tail",
 "software_versions":{"python_flint":flint.__version__,"sympy":sympy.__version__},
 "precision_bits":ctx.prec,"series_cap":ctx.cap,"prime_cutoff":X,
 "prime_count":len(prime_list),"Cxi_ball":str(Cxi),
 "finite_prime_sum_ball":str(t_part),
 "nonnegative_prime_tail_upper_ball":str(prime_tail_upper),
 "kappa_lower_exact_rational":str(kappa_lower.fmpq()),
 "kappa_upper_exact_rational":str(kappa_upper.fmpq()),
 "certified_simple_enclosure":{"lower":"-7/50","upper":"-2/25"},
 "checked_integer_cutoff_inequality":True,
 "proof_of_tail":"P(l)=(256/243)(l^2-4l+11/6); for l>=log10000>8, P>0 and 2P-P'>0. Partial summation with theta(x)<=4x gives tail<=4*(256/243)/10000*(2L^2-6L+5/3)."
}
print(json.dumps(out,indent=2))
