"""Verify the original archive before regenerating its output files."""
from pathlib import Path
import hashlib
import sys

base=Path(__file__).resolve().parent.parent
failed=[];count=0
for line in (base/'SHA256SUMS.txt').read_text().splitlines():
    if not line.strip():continue
    expected,name=line.split('  ',1)
    path=base/name
    if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest()!=expected:
        failed.append(name)
    count+=1
if failed:
    print('Checksum mismatches:',*failed,sep='\n')
    sys.exit(1)
print('PASS:',count,'archived files match SHA-256 manifest')
