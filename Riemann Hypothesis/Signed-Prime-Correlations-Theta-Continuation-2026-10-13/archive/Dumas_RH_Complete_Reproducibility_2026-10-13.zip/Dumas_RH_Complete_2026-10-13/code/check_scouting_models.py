"""Exact scouting examples; no finite model is treated as an RH certificate."""
import json
from pathlib import Path
import sympy as s
assert __debug__
x=s.symbols('x')
roots=[6,8,11,13,19]
p=s.prod(x-r for r in roots)
primitive=s.integrate(6*p,x)
areas=[abs(primitive.subs(x,b)-primitive.subs(x,a)) for a,b in zip(roots,roots[1:])]
expected=[s.Rational(11696,5),s.Rational(30267,10),s.Rational(6696,5),s.Rational(476712,5)]
assert areas==expected
assert areas[0]<areas[1]>areas[2]<areas[3]
u,K,a=s.symbols('u K a',positive=True)
negative_log=9*u*u+K*s.sqrt(u*u+K**-6)+a*s.cosh(2*u)
curvature=s.diff(negative_log,u,2)
assert s.simplify(curvature-(18+K**-5/(u*u+K**-6)**s.Rational(3,2)+4*a*s.cosh(2*u)))==0
assert s.factorial(4)/s.factorial(2)**2==6
out={'status':'PASS','lobe_areas':[str(v) for v in areas],
 'lobe_pattern':'increase, decrease, increase: not single-valley',
 'strong_curvature_formula_verified':True,
 'scaled_exponential_moment_ratio':'6',
 'limiting_scaled_first_residue':'-16',
 'scope':'Exact algebra for adversarial models. Theta-root numerical observations and the full harmonic signed integral are not certified by this script.'}
dst=Path(__file__).resolve().parents[1]/'results/scouting_model_checks.json'
dst.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
