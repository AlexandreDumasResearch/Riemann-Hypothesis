"""High-precision diagnostics only; no outward-rounded certificate."""
import json
import mpmath as mp
from sympy import mobius
mp.mp.dps=70
b=mp.mpf(16)/9
def xi(s):
    return s*(s-1)*mp.power(mp.pi,-s/2)*mp.gamma(s/2)*mp.zeta(s)/2
def L(z):
    return mp.log(xi(mp.mpf(1)/2+mp.sqrt(mp.mpf(9)/4-4*z))/xi(2))
s=[-mp.diff(L,0,j)/mp.factorial(j-1) for j in (1,2,3)]
Cxi=b*(4*s[0]-4*s[1]+s[2])
def logz(s):return mp.log(mp.zeta(s))
J=[]
for j in (1,2,3):
    J.append((-1)**j*sum(int(mobius(k))*mp.mpf(k)**(j-1)*mp.diff(logz,2*k,j) for k in range(1,81)))
tinf=(mp.mpf(256)/243)*J[2]-(mp.mpf(1024)/243)*J[1]+(mp.mpf(1408)/729)*J[0]
anomaly=mp.mpf(128)/6561
C=Cxi/2+tinf-anomaly
kappa=(mp.mpf(36)/5)**2*mp.power(506,-mp.mpf(26)/41)
r={"status":"nonvalidated high-precision diagnostics", "mpmath_dps":mp.mp.dps,"mobius_cutoff":80,"shifted_log_coefficients":list(map(str,s)),"Cxi":str(Cxi),"ordinary_prime_limit_kernel_sum":str(tinf),"prime_square_boundary_anomaly":str(anomaly),"sector_limit_C":str(C),"RH_conditional_mean_U":str(tinf-anomaly),"outer_tail_exponential_base_kappa":str(kappa)}
print(json.dumps(r,indent=2))
