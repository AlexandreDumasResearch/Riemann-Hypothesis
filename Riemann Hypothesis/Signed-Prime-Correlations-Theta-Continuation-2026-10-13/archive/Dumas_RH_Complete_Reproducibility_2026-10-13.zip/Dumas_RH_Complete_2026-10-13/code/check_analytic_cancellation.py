#!/usr/bin/env python3
"""Exact algebra and adversarial finite checks for the pointwise sector lemma.
Numerical envelope samples are diagnostics, not proof or certification.
"""
from pathlib import Path
import json, math, sys
import scipy
import sympy as s
from scipy.special import eval_laguerre
import numpy as np
n,t=s.symbols('n t', positive=True)
w=s.Function('w')(t)
x=t*t/(4*n)
u=s.sqrt(t)*w/2
Dx=lambda z: s.diff(z,t)*2*n/t
res=s.simplify((Dx(Dx(u))+(n/x-s.Rational(1,4))*u)/(2*n*n/t**s.Rational(3,2)))
expected=s.diff(w,t,2)+(1-s.Rational(3,4)/t**2-t**2/(16*n*n))*w
assert s.simplify(res-expected)==0

d=[8,32,26,-26,-32,-8]
b=[8,40,66,40,8]
assert sum(d)==0 and sum(b)==162
reconstructed=[b[0]]+[b[j]-b[j-1] for j in range(1,5)]+[-b[-1]]
assert reconstructed==d
assert sum(x*x for x in [4,24,53,53,24,4])==6802
assert 3*6802==20406
assert s.Rational(4,3)*s.Rational(16,9)*s.Rational(7,2)*s.Rational(11,4)<23
assert s.Rational(97,8)<s.Rational(49,4)
maxratio=0.
argmax=None
# Stop at x=500 to avoid floating intermediate overflow. All are diagnostics.
for k in [1,2,3,5,10,20,50,100,200,500,1000,2000]:
    xs=np.geomspace(1e-9,min(k,500),300)
    vals=np.exp(-xs/2)*(eval_laguerre(k,xs)-eval_laguerre(k-1,xs))
    ratios=np.abs(vals)/(k**(-.75)*xs**.25)
    j=int(np.argmax(ratios))
    if ratios[j]>maxratio: maxratio=float(ratios[j]);argmax=[k,float(xs[j])]
assert maxratio<30
out={'exact_checks':{'ode_transform':True,'band_prefixes':True,'derivative_norm':True,'energy_constant':True},'numerical_diagnostics':{'max_scaled_adjacent_laguerre':maxratio,'argmax_n_x':argmax,'proved_constant':30,'status':'floating-point diagnostics only'}}
out['environment']={'python':sys.version.split()[0],'sympy':s.__version__,'scipy':scipy.__version__,'numpy':np.__version__}
p=Path(__file__).resolve().parents[1] / 'results' / 'analytic_cancellation_checks.json';p.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
