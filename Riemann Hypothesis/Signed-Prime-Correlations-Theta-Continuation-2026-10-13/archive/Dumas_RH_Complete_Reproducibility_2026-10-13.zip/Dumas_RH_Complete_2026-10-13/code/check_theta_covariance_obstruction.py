#!/usr/bin/env python3
"""Exact interval consequence of supplied complete-source moment enclosures.
Does not rerun the Arb quadrature; the enclosure provenance is explicitly retained.
"""
import hashlib, json
from fractions import Fraction as Q
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT/'inputs/fresh_moments_0_88.json'
def q(a):
    sign,mantissa,exponent,_=a
    return Q((-1)**sign*mantissa)*Q(2)**exponent
def add(x,y): return (x[0]+y[0],x[1]+y[1])
def neg(x): return (-x[1],-x[0])
def mul(x,y):
    vals=[a*b for a in x for b in y]
    return (min(vals),max(vals))
def square(x): return mul(x,x)
def serialize(x): return {'numerator':str(x.numerator),'denominator':str(x.denominator)}
raw=SRC.read_bytes(); data=json.loads(raw)
I=[tuple(map(q,p)) for p in data['source_moments'][:4]]
assert all(0<a<=b for a,b in I)
mu=[(a/I[0][1],b/I[0][0]) for a,b in I]
a,b,c=mu[1:4]
D=add(add(mul((Q(2),Q(2)),square(b)),neg(mul(square(a),b))),neg(mul(a,c)))
L=Q('0.00000260910828551675'); U=Q('0.00000260910828551676')
assert L<D[0]<=D[1]<U
# Check the construction algebraically using symbolic independent moments.
import sympy as s
m1,m2,m3,v=s.symbols('m1 m2 m3 v')
det=2*m2**2-m1**2*m2-m1*m3
var=m2-m1**2; cov=m3-m1*m2
alpha=(cov-4*v*m2)/det; beta=(2*v*m1-var)/det
assert s.cancel(-m1*alpha-2*m2*beta)==1
assert s.cancel((var*alpha+cov*beta)/v)==-2
out={
 'status':'PASS',
 'scope':'Exact rational propagation from supplied validated moment intervals; quadrature not rerun by this script.',
 'input_sha256':hashlib.sha256(raw).hexdigest(),
 'D_formula':'2*mu2^2-mu1^2*mu2-mu1*mu3',
 'D_interval':[serialize(x) for x in D],
 'readable_strict_enclosure':[str(L),str(U)],
 'symbolic_checks':{'A_is_one':True,'B_is_minus_two':True,'C_is_minus_one':True},
 'claim_limit':'The centered degree-four test is not asserted to be an actual Laguerre predecessor-root test.'
}
DST=Path(__file__).resolve().parents[1]/'results'/('theta_covariance_obstruction_certificate.json')
DST.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k!='D_interval'},indent=2))
