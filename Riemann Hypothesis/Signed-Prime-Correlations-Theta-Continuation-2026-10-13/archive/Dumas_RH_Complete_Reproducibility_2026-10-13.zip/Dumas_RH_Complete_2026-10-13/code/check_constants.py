"""Exact rational witnesses for the source curvature and primitive window."""
from fractions import Fraction as Q
from math import factorial
from pathlib import Path
import json
import sympy as s

assert __debug__, 'Run without -O.'
c=Q(314159,100000)
checks=[]
def verify(condition, label):
    assert condition, label
    checks.append(label)
verify(16*sum(((-1)**k*Q(1,5)**(2*k+1)/Q(2*k+1) for k in range(6)),Q(0))-Q(4,239)>c,'Machin lower witness')
verify(sum(((3*c)**k/Q(factorial(k)) for k in range(61)),Q(0))>Q(10**8,8071),'first exponential upper witness')
verify(sum(((5*c)**k/Q(factorial(k)) for k in range(81)),Q(0))>Q(10**9,151),'second exponential upper witness')
v=128*(3*c+1)**2*Q(8071,10**8)/(1-36*Q(151,10**9))
verify(v==Q(8771226203214559,7812457531250000),'exact source variance substitution')
verify(v<Q(9,8),'source variance allowance')
verify(Q(96,5)-Q(9,8)==Q(723,40)>18,'source curvature reserve')
x=s.symbols('x')
roots=[s.Rational(1,5),s.Rational(2,5),s.Rational(8,5),s.Rational(9,5)]
p=s.prod(x-r for r in roots)
B=x**5-5*x**4+s.Rational(25,3)*x**3-5*x**2+s.Rational(144,125)*x
verify(s.expand(s.diff(B,x)-5*p)==0,'primitive derivative')
theta=[-B.subs(x,r) for r in roots]
L=max(theta[i] for i,r in enumerate(roots) if s.diff(p,x).subs(x,r)<0)
U=min(theta[i] for i,r in enumerate(roots) if s.diff(p,x).subs(x,r)>0)
verify(L==-s.Rational(838,9375),'primitive lower threshold')
verify(U==-s.Rational(2754,3125),'primitive upper threshold')
verify(L>U,'empty primitive window')
result={'scope':'Exact finite rational witnesses, not an RH proof.','count':len(checks),'passed':checks}
out=Path(__file__).resolve().parent.parent/'results'/'constant_checks.json'
out.write_text(json.dumps(result,indent=2)+'\n')
print('PASS',len(checks),'exact constant checks')
