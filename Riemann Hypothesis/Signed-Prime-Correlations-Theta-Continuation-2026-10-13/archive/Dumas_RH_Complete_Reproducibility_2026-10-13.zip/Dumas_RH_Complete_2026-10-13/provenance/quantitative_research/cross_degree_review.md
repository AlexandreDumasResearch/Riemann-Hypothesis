# Independent focused mathematical review

Reviewed `cross_degree.md` and `analytic_cancellation.md` from their displayed definitions, without assuming their conclusions. This is a mathematical rederivation of the new arguments, not a repeat of the flagship audit. No new numerical experiment was needed.

## A. Cross-degree Gram and compact discrepancy

**Verdict:** no material proof defect found. The uniform arbitrary-width theorem follows from the displayed hypotheses. Its interpretation requires the normalization caveat below, which the authoring agent reports has already been inserted into `cross_degree_candidate.tex`.

1. **Independent Gram calculation.** For the high-band coefficient vector \(d\), the ordinary autocorrelations are
\[
C_0=3528,\ C_1=1500,\ C_2=-1248,\ C_3=-1440,
\ C_4=-512,\ C_5=-64,
\]
with \(C_j=0\) for \(j\ge6\) and \(C_{-j}=C_j\). The Laguerre Jacobi recurrence gives the coefficient of \(m\) in the lag-\(k\) weighted product as
\[
a_k=2(2C_{2k}-C_{2k-1}-C_{2k+1}).
\]
This independently yields \((8112,-5112,960,128)\). Reflection symmetry of the two shifted bands gives the affine midpoint \(m+(k+1)/2\), hence the stated exact matrix. All lags \(k\ge4\) vanish by support.

2. **Synthesis and discrepancy.** The two synthesis norm bounds follow from parity convolution: \(132\cdot66/3=2904\) and \(3\cdot162\cdot81=39366\). Every high band vanishes at zero because \(\sum d_j=0\). Thus the constant limit of the prime discrepancy contributes no endpoint in the integration by parts. Multiplication by the bounded function \(E_D-E_{D,\infty}\), which tends to zero, is compact from \(H^1(0,\infty)\) to \(L^2\): compact restriction followed by Rellich, plus a uniformly small tail. Both terms in the displayed self-adjoint remainder are consequently compact. The norm constant is correct:
\[
2\sqrt{2904\cdot39366}=21384.
\]
The form identity is first an identity on finitely supported sequences; it does not assert that the unnormalized linear-growth Jacobi matrix is bounded on ordinary \(\ell^2\).

3. **Normalized coercivity.** The symmetrized weight factor differs from one by at most \(k^2/[8(M+1/2)^2]\). Summing both sides of the seven-diagonal matrix gives
\[
\frac{c_L^2}{36}(5112+4\cdot960+9\cdot128)
=\frac{842c_L^2}{3}.
\]
The symbol polynomial decreases on \([-1,1]\), so its precise range is \([64,20000]\). The proposed zero-sum long-block tests attain both endpoints in the limit after locating their support much farther out than their width.

4. **Moving cutoffs.** The correction from each original cutoff has squared prime-sampling norm at most \((1408/2187)(\log X_m)/\sqrt{X_m}\), by the scalar absolute tail and the uniform kernel bound. The weighted synthesis correction is Hilbert–Schmidt, with norm at most the stated \(\beta_M\). The geometric estimate uses \((m+2)/(m+1/2)\le2\), valid for every \(m\ge1\). The perturbation bound for squared norms proves the stated \(\epsilon_M\), uniformly over arbitrary support widths. No cutoff interchange is needed.

5. **Full low-band terms.** Their cross sequence is in \(\ell^2\) by the two finite-band Bessel bounds applied to \(E_Dq_\infty\) and \(E_Dq'_\infty\). The continuous cross integral has finite index support. This justifies the fixed-lag constant \(D_\infty\).

**Necessary scope qualification:** coercivity is relative to
\(\sum_m(m+1/2)|u_m|^2\). It does not prohibit reducing the *absolute* diagonal contribution by averaging with smaller coefficients. For example, take coefficients \(+1/W\) on one width-\(W\) block and \(-1/W\) on an adjacent width-\(W\) block beginning near \(M\). Their sum is zero and their weighted energy is \(2M/W+O(1)\), so broad averaging can have bounded diagonal cost. What is ruled out is cancellation below the fixed positive proportion of the prescribed weighted coefficient energy. An uncentered average has nonzero coefficient sum and does not cancel the low band. Nothing here bounds the distinct-prime contribution or excludes a successful cross-prime argument using degree averaging.

## B. Effective pointwise auxiliary-sector bound

**Verdict:** the proof of
\[
r_m=O\bigl(m^{-3/4}\log^{5/2}(m+2)\bigr)
\]
is valid as stated, with constants effective from a supplied valid PNT envelope. No RH-level estimate is used.

1. The transformation \(u=xe^{-x/2}L_{n-1}^{(1)}(x)\) gives \(u''+(n/x-1/4)u=0\). With \(t=2\sqrt{nx}\), the displayed series and normalization give
\[
W''+\left(1-\frac3{4t^2}-\frac{t^2}{16n^2}\right)W=0,
\quad e^{-x/2}(L_n-L_{n-1})=-n^{-3/4}x^{1/4}W/\sqrt2.
\]
The interval \(2\le t\le2n\) corresponds exactly to \(1/n\le x\le n\). Its coefficient has at most one interior maximum and lies in \([9/16,1]\). The logarithmic-variation bound and energy estimate are correct; the derived \(|W|<23\) easily implies the conservative constant 30. The separate power-series estimate covers \(0\le x\le1/n\), including \(n=1\).

2. The five partial sums \((8,40,66,40,8)\) reproduce the complete six-band vector. Their sum is 162; therefore \(K_m=4860c_L3^{1/4}(2m-1)^{-3/4}\) is correct. The high derivative band's exact squared norm is \(20406c_L^2\).

3. The prime-square Stieltjes estimate retains the endpoint term \(E(L)Q_m(L)\) and the full measure \(dM\). The continuous variation bound is \((2/5)K_mL^{5/4}\). The square-integral of the PNT envelope is exactly
\[
A^2e^{-2c\sqrt L}\left(\sqrt L/c+1/(2c^2)\right).
\]
Choosing \(L=c^{-2}\log^2(m+2)\) eventually lies in the proved Laguerre range. It gives the stated logarithmic power. The \(128/6561\) correction is not changed.

4. The higher-power splitting is valid since \(p^{-k/2}=p^{-5k/12}e^{-k\log p/12}\). The exponent \(e^{-(2m-1)/36}\) and the supplied convergent constants follow. All prime powers remain present.

5. The gamma normalization checks independently: \(j_\pi=256/27\), the odd Fourier coefficient of \(-\log(2\cos(\theta/2))\) is \(-1/(2m+1)\), and the cosine norm is \(\pi/2\). Thus the leading gamma contribution is exactly \(-32/[27(2m+1)]\). Differentiated Stirling expansion gives \(R_\Gamma''=O(1+|\log(\pi-\theta)|)\) at the difficult endpoint and zero endpoint first derivatives. This justifies two integrations by parts and the explicit \(L^1\)-norm remainder.

**Reporting limits:** no numerical value of the global constant is certified merely by specifying its effective PNT and polygamma ingredients. Also the gamma expansion is not an asymptotic for the whole \(r_m\), whose prime-power part can be larger than \(1/m\). The conclusions \(r\in\ell^p\) for every \(p>4/3\) and the displayed weighted-square bounds follow; the endpoints \(p=4/3\) and weight exponent \(1/2\) do not follow from this estimate.
