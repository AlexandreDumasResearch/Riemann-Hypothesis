# Effective pointwise extraction of the auxiliary sectors

Status: unconditional, self-contained analytical proof. The square-summability theorem has the stronger pointwise consequence

\[
 r_m=O\bigl(m^{-3/4}(\log(m+2))^{5/2}\bigr).
\]

All constants can be bounded from a specified classical PNT envelope. This controls `U_m+h_m-kappa`, not `U_m` independently, and makes no new assertion about RH. The exact cutoff error remains included. A separate companion argument gives a sharper aggregate tail without the logarithmic loss; these statements are complementary.

## 1. An elementary uniform adjacent-Laguerre estimate

For every integer n>=1 and 0<=x<=n,

\[
 |e^{-x/2}(L_n(x)-L_{n-1}(x))|\le30n^{-3/4}x^{1/4}.                 \tag{A1}
\]

This does not rely on a nonuniform fixed-x asymptotic. Let

\[
 u(x)=x e^{-x/2}L_{n-1}^{(1)}(x),\qquad
 D_n(x)=e^{-x/2}(L_n-L_{n-1})=-u(x)/n.
\]

The Laguerre equation gives `u''+(n/x-1/4)u=0`. Set t=2sqrt(nx), and define

\[
 J_n(t)=e^{-t^2/(8n)}\sum_{j=0}^{n-1}(-1)^j
 \Bigl[\prod_{r=1}^j(1-r/n)\Bigr]
 \frac{(t/2)^{2j+1}}{j!(j+1)!},\quad W_n(t)=\sqrt t\,J_n(t).
\]

Direct substitution gives

\[
 W_n''+p_n(t)W_n=0,\qquad
 p_n(t)=1-\frac3{4t^2}-\frac{t^2}{16n^2},\qquad
 D_n(x)=-\frac{n^{-3/4}x^{1/4}}{\sqrt2}W_n(2\sqrt{nx}).             \tag{A2}
\]

At t=2, the absolutely majorized finite power series gives
`|J_n(2)|<=e` and `|J_n'(2)|<=2e`. (The derivative of the series is bounded by 3e/2, and the derivative of the exponential contributes at most e/2.) Therefore

\[
 |W_n(2)|^2\le2e^2,\quad |W_n'(2)|^2\le81e^2/8.
\]

On 2<=t<=2n one has 9/16<=p_n(t)<=1. Its derivative
`3/(2t^3)-t/(8n^2)` has at most one zero, so

\[
 \int_2^{2n}|p_n'(t)|/p_n(t)\,dt\le2\log(16/9).
\]

The energy H=W'^2+pW^2 satisfies H'=p'W^2, and hence

\[
 H(t)\le(97e^2/8)(16/9)^2,\qquad
 |W_n(t)|\le(4/3)(16/9)\sqrt{97/8}\,e<23.
\]

The assertion follows from (A2) whenever 1/n<=x<=n. If 0<=x<=1/n, the original polynomial series gives `|D_n(x)|<=ex<=e n^{-3/4}x^{1/4}`. Thus the displayed constant 30 is valid throughout the stated interval, including zero and n=1.

## 2. Application to the actual complete six-term band

Write Q_m=q_m-q_infinity, c_L=32/2187, and N_m=2m-1. The exact coefficients are d=(8,32,26,-26,-32,-8). Their successive partial sums are (8,40,66,40,8), summing to 162. Thus

\[
 Q_m(\ell)=c_L\sum_{j=0}^4b_j e^{-3\ell/2}
   [L_{2m-2+j}(3\ell)-L_{2m-1+j}(3\ell)],\quad b=(8,40,66,40,8).
\]

Applying (A1) to the five differences gives, for 0<=3ell<=N_m,

\[
 |Q_m(\ell)|\le K_m\ell^{1/4},\qquad
 K_m=4860c_L3^{1/4}N_m^{-3/4}.                                   \tag{A3}
\]

Two global bounds needed for the tails are

\[
 \|Q_m'\|_2=c_L\sqrt{20406}=:V_1,
 \qquad |Q_m(\ell)|\le2816/729=:V_0.                             \tag{A4}
\]

The first is exact Laguerre orthogonality applied to the high derivative band e=(4,24,53,53,24,4), whose squared coefficient sum is 6802. This holds also for m=1,2 because Q_m has no low band. The second follows from the nonnegative rational spectra and `q_m(0)=q_infinity(0)=1408/729`.

## 3. Effective prime-square bound

Let M(ell)=sum_{2log p<=ell}log(p)/p=ell/2+b+E(ell), as in the manuscript. Choose any *specified valid* classical PNT envelope

\[
 |E(\ell)|\le A e^{-c\sqrt\ell}\qquad(\ell\ge0),                  \tag{A5}
\]

with A,c>0. The independently derived explicit envelope in `effective_sector.md`, based on Trudgian (2016), permits the concrete choice A=1024 and c=1/16. For a completely specified large-degree choice, put N=2m-1 and L=256(log N)^2 when N>=10^6; then 3L<=N, since log(10^6)<14 and N/(log N)^2 is increasing there. The estimates below also allow any sharper valid PNT envelope.

For 0<L<=N_m/3, Stieltjes integration by parts on [0,L], using Q_m(0)=0, gives

\[
 \int_0^\infty E Q_m'
 =E(L)Q_m(L)-\int_0^L Q_m\,d(M-\ell/2)+\int_L^\infty E Q_m'.
\]

At an endpoint which is a prime jump use the right-continuous convention for both the Stieltjes integral and E(L); alternatively choose L avoiding the countable jump set. Consequently

\[
\begin{split}
 \left|\int_0^\infty E Q_m'\right|
 \le{}&K_m\left[L^{1/4}M(L)+\frac25L^{5/4}
                    +A e^{-c\sqrt L}L^{1/4}\right]\\
 &+V_1 A e^{-c\sqrt L}
       \left(\frac{\sqrt L}{c}+\frac1{2c^2}\right)^{1/2}.            \tag{A6}
\end{split}
\]

Every term is explicit, including the finite prime sum M(L). A prime-free bound is `M(L)<=2L+4`, obtained by partial summation from `theta(x)<=4x`. The tail term follows by Cauchy--Schwarz and the exact integral of `A^2 exp(-2c sqrt ell)`.

Choose `L=(log(m+2)/c)^2` for sufficiently large m, when L<=N_m/3. The first line is O(m^-3/4 log^(5/2)m), and the second line is O(m^-1 log^(1/2)m). Therefore

\[
 S_{2,m}-S_2[q_\infty]-128/6561
 =O(m^{-3/4}(\log(m+2))^{5/2}).                                  \tag{A7}
\]

The prime-square endpoint correction is unchanged. It is not bounded away or dropped.

## 4. The higher proper powers need no logarithmic loss

Define the absolutely convergent positive constants

\[
 J_3=\sum_p\sum_{k\ge3}\frac{\log p}{p^{k/2}}(k\log p)^{1/4},
 \quad C_3=\sum_p\sum_{k\ge3}\frac{\log p}{p^{5k/12}}.
\]

Both have elementary effective upper bounds. For example
`C_3 <= -zeta'(5/4)/(1-2^-5/12)`; for J_3, use
`sum_{k>=3} k^(1/4)q^k <=3q^3/(1-q)^2` and then an integral bound for `sum_{n>=2}(log n)^(5/4)n^-3/2`.

Split at `ell=N_m/3`. On the lower part use (A3); on the upper part use (A4) and `p^-k/2 <= exp(-N_m/36)p^-5k/12`. This gives the fully effective bound

\[
 |S_{\ge3,m}-S_{\ge3}[q_\infty]|
 \le K_m J_3+V_0 C_3 e^{-N_m/36}.                                 \tag{A8}
\]

Thus this entire sector is O(m^-3/4), retaining every prime and proper-power exponent.

## 5. Exact leading gamma term

Put j(theta)=(2b/a)(b cos^2(theta/2)-2)^2 and g(t)=Re psi(1/4+it/2)-log pi, with a=3/2,b=16/9. Then

\[
 \Gamma_m-\Gamma_\infty=\frac1{4\pi}\int_0^\pi j(\theta)g(a\tan(\theta/2))
          \cos((2m+1)\theta)\,d\theta.
\]

Let j_pi=8b/a and

\[
 R_\Gamma(\theta)=j(\theta)g(a\tan(\theta/2))
                     +j_\pi\log(2\cos(\theta/2)).
\]

Then R_Gamma belongs to W^{2,1}(0,pi) and its first derivative vanishes at both endpoints. At zero every term is smooth and even. At the other endpoint, writing v=pi-theta, the classical differentiable digamma expansion gives `g(t)=log(t/(2pi))+O(t^-2)`, while `j(theta)=j_pi+O(v^2)`. Hence `R_Gamma=C+O(v^2 log v)`, with corresponding first and second derivative bounds O(v log v) and O(1+|log v|), respectively. These are integrable bounds, not formal endpoint substitutions.

The Fourier series
`-log(2cos(theta/2))=sum_{k>=1}(-1)^k cos(k theta)/k`
holds in L2. Two integrations by parts in the remainder therefore give

\[
 \Gamma_m-\Gamma_\infty=-\frac{32}{27(2m+1)}+\rho_m,
 \qquad
 |\rho_m|\le\frac{\|R_\Gamma''\|_1}{4\pi(2m+1)^2}.                \tag{A9}
\]

The norm is a fixed integral of explicitly specified elementary and polygamma functions. It can be bounded effectively using interval evaluation on a compact interval and the differentiated Stirling remainder near the endpoint; no claimed numerical value for that norm is needed here.

## 6. Main conclusion and finite-error formula

Let epsilon_m be the unchanged full moving-cutoff estimate (8.8) in the flagship manuscript. Combining its exact completed-sector identity with (A6), (A8), and (A9) gives

\[
\begin{split}
 |r_m+32/[27(2m+1)]|
 \le{}&\text{right side of (A6)}+K_mJ_3+V_0C_3e^{-N_m/36}\\
 &+\|R_\Gamma''\|_1/[4\pi(2m+1)^2]+\varepsilon_m                 \tag{A10}
\end{split}
\]

for every m>=1 and 0<L<=N_m/3. The finite constants and all infinite tails are specified. Thus

\[
 r_m=O(m^{-3/4}(\log(m+2))^{5/2}).                                \tag{A11}
\]

In particular r belongs to ell^p for every p>4/3, and the pointwise estimate alone gives `sum_{m>=M}|r_m|^2=O(M^-1/2 log^5 M)` and every weighted ell^2 bound `sum m^s |r_m|^2<infinity` for s<1/2. Do not call (A9) an asymptotic for the full r_m: the prime-square and higher-power contributions may be larger than its 1/m gamma term. No bound for the ordinary-prime sequence U_m itself is proved here.

## Primary source for the gamma remainder

NIST DLMF §5.11, equation 5.11.2 and §5.11(ii): https://dlmf.nist.gov/5.11 . The complex-sector digamma remainder bound, followed by Cauchy estimates on discs of radius proportional to |z| lying in |arg z|<=3pi/4, supplies the differentiated bounds used in (A9). The adjacent Laguerre estimate itself was derived above from its differential equation, not imported from an asymptotic table.

## Check scope

The argument is independent of fixed-degree theta asymptotics, of RH, and of the zero-free-line zeta logarithmic-derivative representation. Its only analytic prime input is the same classical effective PNT error already used in the sector theorem. The Laguerre estimate is derived from its exact ODE rather than cited. The stronger logfree aggregate tail is proved separately through a Laguerre quadratic-form regularization and should not be inferred from (A11).
