# Effective square-summable sector extraction

Status: unconditional theorem with complete elementary proof. No RH hypothesis. This is a candidate for integration, not an edit of the flagship. It complements the sharper pointwise estimate derived in `analytic_cancellation.md`: here the aggregate tail has no logarithmic loss.

## Main conclusion

For the unchanged sequence and constant of Theorem 8.1,

\[
\boxed{\sum_{m=M}^{\infty}|r_m|^2\le 3\cdot10^{12}M^{-1/2}\quad(M\ge2).}
\]

The displayed constant is deliberately coarse; the proof gives a substantially sharper computable expression in the actual prime-square error and a chosen explicit PNT envelope. In particular,

\[
\sum_{m\ge1}m^s|r_m|^2<\infty\quad(0\le s<1/2),\qquad
\sum_{m\le N}|r_m|=O(N^{1/4}).
\]

Thus the *unconditional complete-sector averaging error* is

\[
\frac1N\sum_{m\le N}(\mathcal U_m+h_m)-\kappa=O(N^{-3/4}).
\]

This does not bound the ordinary-prime sequence independently of the zero diagonal. The endpoint weighted assertion at s=1/2 is not claimed.

## 1. Explicit PNT envelope

Primary source checked: T. Trudgian, *Updating the error term in the prime number theorem*, Ramanujan J. 39 (2016), 225--234, DOI 10.1007/s11139-014-9656-6, Theorem 1. Author arXiv PDF https://arxiv.org/pdf/1401.2689, pp. 2--3, states

\[
|\vartheta(x)-x|\le x\sqrt{8/(17\pi)}X^{1/2}e^{-X},\quad
X=\sqrt{\log x/6.455},\quad x\ge149.
\]

This is an unconditional explicit theorem; its use of finitely verified zero information in its own proof is not an RH hypothesis.

Set R(x)=theta(x)-x. Since 6.455<8 and sqrt(X)e^{-X/2}<=1,

\[
|R(e^v)|e^{-v}\le 6e^{-\sqrt v/(4\sqrt2)}\quad(v\ge0).
\]

For x>=149 this follows directly from Trudgian (even with factor 1). For 1<=x<149, theta(x)<=4x implies |R(x)|<=3x; log149<6 and sqrt6/(4sqrt2)<1/2 imply 6e^{-sqrt6/(4sqrt2)}>3.

The exact prime-square error satisfies, with x=e^{ell/2},

\[
E(\ell)=R(x)/x-\int_x^\infty R(t)t^{-2}dt.
\]

Indeed partial summation gives b=1+int_1^infty R(t)/t^2 dt. Consequently

\[
|E(\ell)|\le6(65+8\sqrt\ell)e^{-\sqrt\ell/8}
\le \boxed{w(\ell):=1024e^{-\sqrt\ell/16}}.
\]

For the last inequality use z e^{-z/16}<=16/e<8, so 6(65+8z)e^{-z/16}<774<1024. The envelope w is decreasing. No evaluation of b is needed to obtain it.

## 2. Quantitative Laguerre projection lemma

Let E be the actual right-continuous prime-square error; its variation measure is exactly

\[
dV_E(u)=\tfrac12du+dM(u),\quad
M(u)=\sum_{2\log p\le u}\frac{\log p}{p}.
\]

For any decreasing envelope |E|<=w for which the following quantities are finite, put

\[
K_i=\int_0^\infty u^i w((u-1)_+)dV_E(u)\quad(i=0,1),
\qquad P_1=\int_0^\infty u|E(u)|^2du.
\]

The quantities are computable from finite prime sums and explicit tail integrals. Let psi_j(u)=sqrt3 e^{-3u/2}L_j(3u), alpha_j=<E,psi_j>. For J>=1,

\[
\boxed{
\sum_{j\ge J}|\alpha_j|^2
\le \frac{2K_0+4K_1/3}{\sqrt{J+1/2}}
+\frac{3P_1/2}{J+1/2}.}
\tag{L}
\]

Proof. For 0<delta<=1 form the right Steklov average

E_delta(x)=delta^{-1}int_0^delta E(x+t)dt.

For 0<t<=delta,

|E(x+t)-E(x)|^2 <= 2w(x) int_(x,x+t]dV_E.

Integrating in x and then averaging t gives

\[
\|E_\delta-E\|_2^2\le\delta K_0.
\]

Here the monotonicity of w gives w(x)<=w((u-1)_+) when u in (x,x+t], and the interval of possible x has length at most t. Jensen justifies passing from differences to their average. Also E_delta'(x)=(E(x+delta)-E(x))/delta almost everywhere, so

\[
\int_0^\infty x|E_\delta'|^2dx\le 2K_1/\delta,
\qquad
\int_0^\infty x|E_\delta|^2dx\le P_1.
\]

The scaled Laguerre functions satisfy

\[
-(x\psi_j')'+\tfrac94x\psi_j=3(j+1/2)\psi_j.
\]

Their quadratic form Q(f)=int x|f'|²+(9/4)x|f|² therefore gives

\[
\sum_{j\ge J}|\langle f,\psi_j\rangle|^2
\le \frac{Q(f)}{3(J+1/2)}.
\]

For complete justification without assuming a spectral theorem, integrate by parts against a finite Laguerre expansion g=sum_{j<=L}<f,psi_j>psi_j, apply form Cauchy--Schwarz, and pass L to infinity. The term x f psi_j' vanishes at zero because f=E_delta is bounded there. Truncation and smooth approximation justify the same calculation at infinity and for locally absolutely continuous f. All displayed form integrals are finite.

The inequality |a+b|²<=2|a|²+2|b|² yields

\[
\sum_{j\ge J}|\alpha_j|^2\le2\delta K_0+
\frac{4K_1}{3(J+1/2)\delta}+\frac{3P_1}{2(J+1/2)}.
\]

Choose delta=(J+1/2)^{-1/2}. This proves (L). No asymptotic Laguerre estimate is used.

### Explicit bounds for the constants

From theta(x)<=4x, M(u)<=4+2u. Write g_i(u)=u^i w((u-1)_+). Integration by parts gives

K0 <= 4w(0)+(5/2)int g0,
K1 <= 8int g0+(13/2)int g1.

For K1, use |g1'|<=wshift+u(-wshift') and integrate the latter term; this yields int(4+2u)|g1'| <= int(8+6u)wshift, before adding (1/2)int u wshift.

For w=1024 exp(-sqrtu/16),

\[
\int g_0=525312,\quad \int g_1=805831168,
\]

and hence

\[
\boxed{K_0\le1317376,\quad K_1\le5242105088,\quad
P_1\le51539607552.}
\tag{C}
\]

These are exact integers: int_0^infty u^k A exp(-eta sqrtu)du=2A Gamma(2k+2)/eta^{2k+2}. The code checks every rational coefficient.

The exact six-term derivative band gives, for M>=2 and J=2M-2,

\[
\sum_{m\ge M}|\langle E,q_m'-q_\infty'\rangle|^2
\le \frac{2048}{243}
\left[\frac{2K_0+4K_1/3}{\sqrt{2M-3/2}}+
\frac{3P_1/2}{2M-3/2}\right].
\tag{S}
\]

This is the manuscript's exact finite-band Bessel bound restricted to the tail; 39366 c_L²=2048/243. Every band index occurring when m>=M is >=2M-2.

## 3. Explicit Fourier-tail lemma

Let y=pi-theta and c_k(F)=sqrt(2/pi)int_0^pi F(theta)cos(k theta)dtheta. If

|F|<=L0 and |F'|<=L1 y^-2,

then for integer K>=1,

\[
\sum_{k\ge K}|c_k(F)|^2\le(8L_0^2+\tfrac23L_1^2)K^{-1/2}.
\tag{F1}
\]

Proof: replace F by its constant endpoint continuation from theta=pi-epsilon. The L² approximation error is <=4L0² epsilon; the derivative norm squared is <=L1²/(3epsilon³). The cosine basis diagonalizes the Neumann form int|F'|², so the same 2-splitting gives 8L0²epsilon+2L1²/(3K²epsilon³). Set epsilon=K^-1/2. This is valid because epsilon<=1<pi.

If instead |F|<=G0 y^-1/4 and |F'|<=G1 y^-5/4, the same argument gives

\[
\sum_{k\ge K}|c_k(F)|^2\le(12G_0^2+\tfrac43G_1^2)K^{-1/2}.
\tag{F2}
\]

Here the squared approximation error is <=6G0²sqrt(epsilon), derivative energy <=(2/3)G1²epsilon^-3/2, and epsilon=K^-1.

### Higher powers

Let J(theta)=F(t(theta))t'(theta), so J0:=sup|J|<10, J1:=sup|J'|<9; explicitly J0=8b/a and J1<=4b²/a. Define

H0=sum_{p,k>=3}logp/p^{k/2}<20,
H1=sum_{p,k>=3}k(logp)²/p^{k/2}<1000.

For the inequalities, bound primes by all integers, use 1/(1-1/sqrt2)<4, sum_{n>=2}(log n)/n^{3/2}<5, and sum_{n>=2}(log n)²/n^{3/2}<20. The last two follow by the integral test with the single maximum split; the integrals over [1,infinity) are 4 and 16, respectively.

For A_H(theta)=J(theta)H_{>=3}(t(theta)),

|A_H|<=200,
|A_H'|<=80000 y^-2.

Indeed t'<=a pi²/(2y²), pi²<10. Thus (F1) applies with C_H=8(200)²+(2/3)(80000)².

### Gamma term

For g(t)=Re psi(1/4+it/2)-logpi one has

|g(t)|<=6+72log(1+t), and 0<=g'(t)<=72/(1+t).

Proof: g(0)=-gamma-pi/2-3log2-logpi has magnitude <6. Its differentiated absolutely convergent digamma series is

\[
g'(t)=\sum_{j=0}^\infty\frac{(t/2)(j+1/4)}{((j+1/4)^2+t^2/4)^2}.
\]

For t<=1, it is <=(t/2)(64+int_0^infty(x+1/4)^-3 dx)=36t. For t>=1, the sum of the unimodal positive summand is at most its integral over [0,infinity) plus twice its maximum, giving 1/t+9/(2sqrt3 t²)<4/t. These imply 72/(1+t). Integrating gives the g bound.

With t=a cot(y/2), one has t<=3/y and y t'/(1+t)<4. Therefore

|g(t(theta))|<=G* y^-1/4, G*<300,
|d_theta g|<=288/y.

For the first inequality use y^{1/4}log((pi+3)/y)<=4(pi+3)^{1/4}/e and pi^{1/4}<3/2, (pi+3)^{1/4}<2. Thus A_gamma=Jg/2 satisfies

|A_gamma|<=1500 y^-1/4,
|A_gamma'|<=8000 y^-5/4.

Apply (F2) with C_gamma=12(1500)²+(4/3)(8000)².

Both actual sector coefficients equal (1/(2pi))int A cos((2m+1)theta), hence their squared Fourier normalization factor is 1/(8pi). The gamma and higher-power tail bounds therefore are respectively C_gamma/(8pi sqrt(2M+1)) and C_H/(8pi sqrt(2M+1)).

## 4. Exact moving cutoff and global constant

Let r0=5/36, delta=26/41, s=506^{-delta}, rho=r0^{-2}s, and

A=(128/2187)((1+delta)/delta)(132+80/r0+16/r0²),
B=(64/2187)((1+delta)/delta)4(1+2r0)²(2+r0)²r0.

The full stencil moving-tail bound already proved in the manuscript is

|U_m-t_m|<=A s^{m+2}+B rho^{m+2}.

Thus its square tail is at most

\[
T_M=\frac{2A^2s^{2(M+2)}}{1-s^2}+\frac{2B^2\rho^{2(M+2)}}{1-\rho^2}.
\]

The exact four-component splitting gives the computable bound

\[
\boxed{
\sum_{m\ge M}|r_m|^2\le
\frac{8192}{243}\left[
\frac{2K_0+4K_1/3}{\sqrt{2M-3/2}}+
\frac{3P_1/2}{2M-3/2}\right]
+\frac{C_\gamma+C_H}{2\pi\sqrt{2M+1}}+4T_M.}
\tag{Q}
\]

All constants correspond to the unchanged complete sectors. The prime-square endpoint 128/6561 has already been extracted in kappa; it is not estimated away.

For a simple numerical closed bound use (C), 2M-3/2>=M for M>=2, and pi>3. The square part is <2.842e12 M^-1/2; Fourier parts <1e9 M^-1/2. The moving tail obeys A<300, B<1, s<1/50, rho<2999/3000. The last two comparisons reduce to the exact integer inequalities

506^26>50^41,
36^82 3000^41 <5^82 506^26 2999^41.

Consequently 4T_M<10^6 M^-1/2: use 1-rho²>1/2000, sqrt(M)e^{-M/1500}<30, and the negligible 50^{-2(M+2)} term. Formula (Q) is therefore strictly below 3e12 M^-1/2.

## 5. Consequences and limits

Weighted summability follows by dyadic blocks: the block contribution to sum m^s r² is O(2^{j(s-1/2)}). Cauchy--Schwarz on each block gives sum_{2^j<=m<2^{j+1}}|r_m|=O(2^{j/4}); summing blocks gives O(N^1/4). The m=1 term is finite and harmless; there is no claim it has been numerically bounded by the tail constant.

The exponent 1/2 here is an upper-tail estimate, not a proved optimal exponent for the actual complete remainder. No lower bound, endpoint weighted failure, or RH-strength ordinary-prime cancellation is claimed. The coarse constant is a proof of full effectivity, not evidence of a practically useful onset degree. A tighter w and finitely computed weighted variation constants improve (Q) without changing the theorem.
