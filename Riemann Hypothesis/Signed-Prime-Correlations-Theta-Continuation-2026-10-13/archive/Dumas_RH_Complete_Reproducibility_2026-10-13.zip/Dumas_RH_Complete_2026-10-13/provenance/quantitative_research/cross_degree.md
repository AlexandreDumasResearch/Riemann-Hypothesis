# Cross-degree prime sampling: a new unconditional theorem

All notation is the integrated manuscript's. Put c=32/2187, q_inf=c exp(-3l/2)(132-288l+72l²), H_m=q_m-q_inf, X_m=506^(m+2), and w_p=(log p)²/p. No change to any theta source or ordinary-prime coefficient is made.

## Main theorem

Let a_0=8112, a_1=-5112, a_2=960, a_3=128, and a_k=0 for k>3. For every finite complex sequence u, the uncut high-band prime form is

 sum_p w_p |sum_m u_m H_m(log p)|² = sum_(m,n) conjugate(u_m) J_(m,n)u_n + <u,Ru>,
 J_(m,n)=(c²/9)a_|m-n|(m+n+1)/2.

Here R is a compact self-adjoint operator on ordinary ell². In particular its entries tend uniformly to zero when min(m,n) tends to infinity. One has the explicit bound
 ||R|| <= 21384 c² ||E_D-E_D,infinity||_infinity,
 E_D(L)=sum_(p<=expL) (log p)²/p-L²/2.
Classical unconditional PNT implies that E_D converges to a finite constant and is bounded. No RH-strength error is used.

The associated Toeplitz symbol is
 a(theta)=8112-10224 cos(theta)+1920 cos(2theta)+256 cos(3theta),
 64 <= a(theta) <= 20000.
Both constants are optimal, even when restricting to coefficients with sum u_m=0.

Define actual-cutoff centered kernels Htilde_m(log p)=1_(p<=X_m)q_m(log p)-q_inf(log p). Uniformly for all finite sequences supported on m>=M,
 (64c²/9-epsilon_M) sum_m(m+1/2)|u_m|²
 <= sum_p w_p |sum_m u_m Htilde_m(log p)|²
 <= (20000c²/9+epsilon_M) sum_m(m+1/2)|u_m|²,
where epsilon_M is specified below in terms of the unconditional PNT discrepancy bound and tends to zero. The discrepancy constant has not been numerically enclosed here. Thus this statement is uniform over arbitrary block widths and arbitrary complex coefficients, not merely each fixed degree shift.

If sum u_m=0, the centering cancels exactly: the middle expression is the diagonal prime part of the exact degree-filtered ordinary-prime statistic sum_m u_m U_m. Consequently no nonzero degree filter can erase the diagonal Rayleigh quotient relative to its weighted coefficient norm. Broad averaging can still reduce absolute energy by shrinking that norm. This is an unconditional source-preserving operator estimate. It does not bound the cross-prime terms, whose cancellation is still essential.

## Proof

The exact six-band formula is H_m(l)=c exp(-3l/2) sum_(j=0)^5 d_j L_(2m-2+j)(3l), d=(8,32,26,-26,-32,-8). Its derivative band has e=(4,24,53,53,24,4). Weighted Cauchy-Schwarz and the sum of each parity of the coefficients give
 ||sum u_m H_m||² <= 2904c² ||u||²,
 ||sum u_m H'_m||² <= 39366c² ||u||².
(The first nonsharp synthesis bound uses sum|d|=132 and each parity sum=66; the second uses sum e=162 and each parity sum=81.) Thus synthesis S:u->sum u_mH_m is bounded ell²->H¹ and derivative synthesis D is bounded ell²->L². Each H_m(0)=0.

For Q=sum u_mH_m, Stieltjes integration by parts is legitimate because Q is an exponential times a polynomial. It gives
 sum_p w_p|Q(log p)|² = integral l|Q(l)|² dl - 2 Re integral E_D(l) conjugate(Q(l))Q'(l)dl.
The constant E_D,infinity has zero contribution because Q(0)=Q(infinity)=0. Multiplication by E_D-E_D,infinity is compact H¹(0,infinity)->L²: truncate to a compact interval, use Rellich there, and use uniform decay of the multiplier for the remaining tail. Thus
 R=-(D* M S+S* M D), M= multiplication by E_D-E_D,infinity,
is compact self-adjoint; its norm is <=2sqrt(2904*39366)c²||M||=21384c²||M||.

The Laguerre recurrence xL_j=(2j+1)L_j-(j+1)L_(j+1)-jL_(j-1) computes the continuous form exactly. Only degree shifts k<=3 survive, and direct finite arithmetic gives
 integral l H_m(l)H_(m+k)(l)dl=(c²/9) a_k(m+(k+1)/2), k=0,1,2,3,
and zero for k>=4. This is J.

Normalize by L_m=m+1/2. Then L^(-1/2)J L^(-1/2)=(c²/9)T_a+K, where T_a is the Toeplitz operator with diagonals a_k and K is banded with entries tending to zero. For indices m,n>=M and |m-n|=k,
 0<=(L_m+L_n)/(2sqrt(L_mL_n))-1 <= k²/[8(M+1/2)²].
The row-sum bound therefore yields
 ||K restricted to indices>=M|| <= 842c²/[3(M+1/2)²].
Moreover ||L^(-1/2) R L^(-1/2)|| on the same tail <= ||R||/(M+1/2).
The Toeplitz form is (2pi)^(-1) integral a(theta)|sum u_m exp(imtheta)|² dtheta. In t=cos(theta),
 a=6192-10992t+3840t²+1024t³.
Its derivative is strictly negative on [-1,1], because its convex derivative attains its maximum over that interval at one of the endpoints, whose values are -15600 and -240. Therefore the exact endpoints are a(0)=64 and a(pi)=20000.

For the actual moving cutoffs define T_m(p)=1_(p>X_m)q_m(log p). The existing complete scalar tail, together with |q_m|<=K0=1408/729, yields
 ||T_m||²_(ell²(w)) <= (K0/3)(log X_m)/sqrt(X_m)=:tau_m².
This uses the degree m kernel's own cutoff and is uniform without moving an endpoint. For normalized synthesis and indices m>=M, the tail operator norm is at most
 beta_M=(sum_(m>=M)tau_m²/(m+1/2))^(1/2).
This series has an explicit geometric bound. Set rho=506^(-1/2). Since (m+2)/(m+1/2)<=2 for m>=1,
 beta_M² <= (2K0 log506/3)rho^(M+2)/(1-rho).

Set
 delta_M=842c²/[3(M+1/2)²]+||R||/(M+1/2),
 epsilon_M=delta_M+2sqrt(20000c²/9+delta_M)beta_M+beta_M².
The inequality ||A-B||² differs from ||A||² by at most 2||A||||B||+||B||² proves both moving-cutoff bounds. They remain uniform over arbitrary finite supports. Sharpness follows by long blocks of slowly oscillating coefficients situated at degrees much larger than their block widths: their Toeplitz Rayleigh quotients tend to a(0) or a(pi), while the diagonal weights become constant to relative error o(1). Exact zero-sum blocks can be used: a whole cycle exp(2pi i j/W) for the lower endpoint and even-length alternating coefficients for the upper endpoint.

## Fixed-shift corollary

For every fixed nonnegative integer k,
 sum_(p<=X_m) w_p q_m(log p)q_(m+k)(log p)
 = (c²/9)a_k(m+(k+1)/2)+D_infinity+o(1).
For k>=4 the linear part is exactly zero. The term D_infinity is the existing literal prime sum of q_inf². More strongly, without the common low band, the o(1) is uniform in arbitrary m,n whose minimum tends to infinity.

To prove the full-kernel statement, expand q_m=q_inf+H_m. The low/high cross sequence b_m=sum_p w_p q_inf(log p)H_m(log p) belongs to ell²: the continuous term integral l q_inf H_m is finitely supported by the Laguerre recurrence, and the discrepancy terms are bounded functionals of each finite Laguerre band with L² inputs E_D q_inf and E_D q'_inf. Bessel bounds imply ell². Thus b_m->0. The high/high error is R_(m,m+k)->0 by compactness. Finally the cutoff loss is at most (K0/3)log(X_m)/sqrt(X_m), by applying the actual degree-m tail and bounding |q_(m+k)|<=K0. For arbitrary m,n use the smaller degree's own tail.

## Scope

This gives an actual growing-degree uniform theorem at the level of the ordinary-prime diagonal. It strengthens merely fixed-lag asymptotics and prevents accidental loss of cross-degree diagonal terms. It is NOT a bound for U_m, because summing over pairs of distinct primes is absent from the positive diagonal form. Its spectral gap quantifies the minimum cancellation which genuine cross-prime estimates must fund, and rules out a vanishing diagonal Rayleigh quotient from any nontrivial zero-sum degree filter; this does not prevent normalization effects from reducing absolute energy.
