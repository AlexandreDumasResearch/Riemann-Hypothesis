# Independent theta saddle and heat reconstruction

Date: 13 October 2026. Scope: the full `publication_integrated/source/saddle.tex`
and `heat.tex`, followed by a new contour argument. This is mathematical
reconstruction, not a claim of formal verification or external refereeing.

## Existing coupled-saddle theorem

I did not find a fatal defect in the stated absolute-error theorem. In particular:

* The bridge constant is correct: the `(u,v) -> (s,d)` Jacobian is 2,
  the positive-d half contributes a second factor 2, and extraction of
  `cosh(2yd)` gives `2^(2n+2)/(2n)!`.
* The source's even continuation is needed when `d-s` crosses zero.
  The stated paired estimate includes that crossing. Its C^(-10) bound
  is conservative but sufficient.
* Moving-strip global localization keeps the positive-heat marginal's
  `exp(O_T(log^2(1/C)))` factor. With C >= n^(-A), it is swallowed by
  the true exterior loss exp(-k n/D), not incorrectly called polynomial.
* The mixed term `-i tan(2y) u v` is mandatory. The determinant and the
  resulting Gaussian mass of order C are correct.
* The explicitly displayed linear-plus-cubic term is odd under simultaneous
  sign reversal. Its integral is exactly zero on the symmetric box even
  though the Gaussian is complex. This saves one full Taylor order.
* The complex Taylor inequality uses Re(E), not |E|, in its exponential
  multiplier. Its application remains legitimate when C is very small.
* The original bound is an ABSOLUTE bound. Dividing by its main term costs
  another C^(-1); the old C^(-3) relative condition is handled honestly.
* Every fixed negative heat remains covered. The Rodgers--Tao normalization
  therefore rules out using either the old or new positive region as an
  RH implication by itself.

## A substantive extension

The existing loss is not intrinsic to the local Gaussian. It arises from
integrating the absolute value of the oscillatory cubic error on real
coordinates. The local source variables can be rotated separately.

The exact proof is in `theta_candidate.tex`. It proves, with the same
normalization, the relative bound

    O_{A,T}( C D^3/n
              + (1+nC/D+C^(-1)) exp(-k nC^2/D) ).

At zero heat replace C D^3/n with C D/n. The hypotheses are
C >= n^(-A) and nC^2/D >= 1. In particular for every fixed beta < 1/2
the strip C >= n^(-beta) has relative error O(C D^3/n), or O(C D/n)
at zero heat. The enlarged strict-positive region is

    |x| <= b_n n^(3/2)/(log n)^2,  for every positive b_n -> 0,

uniformly over bounded real heat. This improves the previous
`b_n (n/log n)^(4/3)` region asymptotically.

The mechanism is explicit:

    t_+ = D+iy + sqrt(2)c sqrt(C) exp(-iy) a,
    t_- = D-iy + sqrt(2)c sqrt(C) exp(+iy) b.

The main quadratic is now

    -(a^2+b^2)/2 - C/(8D) (exp(-iy)a+exp(iy)b)^2.

Its real part is uniformly coercive. The complex Jacobian has real
positive product c^2 C, and the determinant is 1+C^2/(2D).
Thus the small main term C is supplied by the Jacobian; it no longer
comes from cancellation lost by an absolute bound in the new coordinates.
The cubic size becomes O(c sqrt(C)(D+1)), and its integral still vanishes
by parity. Every complete-theta mode remains included.

The contour is confined to a box of physical radius rho C, so that all
intermediate source arguments remain in the analytic strip. At an
endpoint arc the loss is exp(-k nC^2/D). This is a genuine restriction
of the present method. The apparent local scale C >> D/n alone does
NOT pay for joining the rotated box to the original contour. No claim
of an exponent-2 positive region is made.

## Heat and harmonic checks

The source-induced successor equation and the raw discriminant budget
have different roles: the former is an exact coefficient identity;
the latter is a continuation criterion whose negative signed response
still needs control. A first collision creates the stated pole in that
response. No unconditional integrability conclusion was found.

The harmonic annihilation is a translation-invariance calculation,
not a positivity theorem. The barycentric Hessian scale grows as N^4.
The positive-diagonal argument establishes radial positivity for each
fixed N; it does not supply a useful N-uniform neighborhood or cutoff.
The eventual-high-derivative result does not resolve the finite initial
jet. The supplied smooth complete-tail counterexample correctly keeps
that obstruction separate from the actual theta source.

The raw finite theta truncation theorem is compatible with all saddle
results: its positive endpoint derivative produces a negative real
Fourier tail at fixed truncation and fixed heat, while its first-mode
large-radius behavior matches the complete source. Neither finite
truncation nor the enlarged high-order region supplies global real
zeros.

## Validation scope

The companion `theta_rotation_checks.py` checks exact algebra at three
rational points on the unit circle, including linear cancellation,
quadratic coefficient, parity, determinant and Jacobian. Those checks
do not certify contour estimates. The proof handles them analytically.
Independent adversarial reading of the new proof was requested from
the proof-reconstruction agent before promotion into the flagship.

The script was executed successfully with SymPy and all 15 assertions
passed; its actual output is `theta_rotation_checks.json`. Independent
proof reconstruction also passed the contour clearance, intermediate
angles, endpoint loss, determinant and positivity corollary. A final
normalization check recovered the half-line identity H_0(w)=xi(1/2+iw),
the full-line identity mathcal H_0=2xi, the bridge factor
2^(2n+2)/(2n)!, the source-product factor 64 pi^4, the exponent -n/D,
the heat contribution 2 tau(D^2-y^2), and the Fourier shift -2xy.
The exact change u=2t gives mathcal H_tau(z)=16 H_RT_(4tau)(2z).
No correction of those factors was necessary.

No new all-degree Jensen-root sign, cold discriminant budget, or signed
ordinary-prime correlation bound has been established by this route.
