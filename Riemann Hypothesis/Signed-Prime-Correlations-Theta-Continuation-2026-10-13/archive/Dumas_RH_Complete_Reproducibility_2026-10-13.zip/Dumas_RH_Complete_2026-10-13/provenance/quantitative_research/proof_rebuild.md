# Independent reconstruction of the square-summable sector theorem

Scope: independently reconstructed the sector identity, endpoint correction,
finite-band estimate, cutoff, and bounded criteria. This is not a new audit of
the full manuscript. The derivation below is independent of the PNT-error
Laguerre-Bessel proof in Section 8.

## 1. Conclusion about the existing theorem

No substantive defect found. In particular the prime-square endpoint shift is
**+128/6561 in S2,m-S2,infinity**, hence **-128/6561 in kappa**. Dropping the
Abel pole at s=1 would give the wrong constant. The bound 39366 cL^2 is correct
and, as an operator bound for arbitrary L2 input, optimal. The moving-cutoff
tail has base (36/5)^2 506^(-26/41)<1; its proximity to one affects practical
constants, not square summability.

Exact independent rational-polynomial checks (stdlib fractions, no external
CAS) were run for m=1,...,14: 28 stencil/differentiation identities passed,
including overlap at m=1,2. The endpoint 128/6561 and integer cutoff inequality
36^41<506^13*5^41 were checked exactly. These finite checks supplement, not
replace, the general telescoping proof.

## 2. A second proof that retains all auxiliary-sector correlations

Let Z(s)=-zeta'(s)/zeta(s), s=1/2+it. For Re(s)>1/2, Euler products give

    sum_p sum_{k>=2} log(p) p^(-ks)
       = Z(2s) + sum_p sum_{j>=1} log(p) p^(-(2j+1)s).

Thus ALL even prime powers collapse into one logarithmic derivative. The
remaining odd powers, beginning at k=3, are absolutely and uniformly convergent
on Re(s)>=1/2. This simplification was not exploited by the existing split
into squares and all k>=3.

For t>0 define

    Z1(t)=Re Z(1+2it),
    Hodd(t)=sum_p sum_{j>=1} log(p) p^(-(2j+1)/2)
                                      cos((2j+1)t log p),
    V(t)=gGamma(t)/2-Z1(t)-Hodd(t).

Set Z1(0)=-EulerGamma, its continuous extension after removal of the imaginary
pole 1/(2it). Let t(theta)=a tan(theta/2),

    J(theta)=F(t(theta)) t'(theta)
            =(2b/a)(b cos^2(theta/2)-2)^2,
    A(theta)=J(theta)V(t(theta)).

Then A is real and belongs to L2(0,pi). Indeed Hodd is bounded; digamma grows
logarithmically; Z on Re(s)>=1 is O(log t) for large t. A classical O(log^2 t)
bound would also suffice. The logarithmic derivative bound is unconditional
and only concerns the already zero-free line Re(s)=1.

Primary source verified directly: Nicol Leong, Explicit estimates for the
logarithmic derivative and the reciprocal of the Riemann zeta function,
arXiv:2405.04869v5 (30 Jan 2026), Corollary 2:
|zeta'/zeta(sigma+it)|<=24.303 log t for sigma>=1,t>=13.
https://arxiv.org/html/2405.04869v5#S2.SS2
Tool source turn89view0, lines87-91. No conditional Corollary3 used.

For every fixed rational test f with exponentially decaying cosine transform q,
insert damping exp(-epsilon k log p), epsilon>0. Absolute convergence permits
Euler-product rearrangement and cosine-transform interchange. Split

    Z(1+2epsilon+2it)=1/(2epsilon+2it)+regular part.

The regular part tends dominatedly to Z1(t): near zero it is uniformly
bounded on a compact rectangle after pole removal, and at large t its growth
is logarithmic uniformly for 0<=epsilon<=1. The half-line pole contribution is

    (1/pi) integral_0^infinity f(t)*epsilon/[2(epsilon^2+t^2)] dt -> f(0)/4.

This limit follows directly by substituting t=epsilon u and splitting the
integral at any fixed small radius. Meanwhile the damped prime sum converges
to the literal undamped sum by its fixed-degree absolute majorant. Consequently

    Spp[q] = f(0)/4 + (1/pi) integral f(t)[Z1(t)+Hodd(t)] dt.

Apply this to f_m=F(1+cos((2m+1)theta))/2. The exact completed-sector identity
now gives

    t_m+h_m = -F(0)/4 + (1/(2pi)) integral A(theta)dtheta
                         +(1/(2pi)) integral A(theta)cos((2m+1)theta)dtheta.

Applying the same identity to f_infinity=F/2 proves that the first two terms
are precisely the existing kappa, since F(0)/8=128/6561. Thus

    a_m := t_m+h_m-kappa
          =(1/(2pi)) integral_0^pi A(theta)cos((2m+1)theta)dtheta.

This proves square summability without using the Laguerre basis or integrating
the PNT error against its derivative band. It also keeps cross-sector
cancellation intact rather than bounding sectors independently.

## 3. Exact tail energy, not merely a Bessel upper bound

Let Aodd(theta)=(A(theta)-A(pi-theta))/2. This is precisely the projection
onto the closed span of the odd cosine modes. Let Pi_M project onto
cos(theta),cos(3theta),...,cos((2M-1)theta). Parseval gives, for M>=1,

    sum_{m>=M}|t_m+h_m-kappa|^2
      =(1/(8pi)) ||Aodd-Pi_M Aodd||_L2(0,pi)^2.

No inequality or discarded mixed-sector term occurs in this identity. The
finite-cutoff discrepancy epsilon_m=U_m-t_m remains exactly the existing
geometric tail. Therefore

    | sqrt(sum_{m>=M}|r_m|^2)
      - ||Aodd-Pi_M Aodd||/sqrt(8pi) |
      <= sqrt(sum_{m>=M}|epsilon_m|^2).

If the manuscript's pointwise cutoff bound is C1 u^(m+2)+C2 v^(m+2),
its l2 tail is bounded by

    C1 u^(M+2)/sqrt(1-u^2)+C2 v^(M+2)/sqrt(1-v^2).

This is a complete source-preserving energy identity; it is not a bound on
the unresolved ordinary-prime sequence. It can be paired with the new
effective-sector tail theorem to obtain explicit error budgets.

## 4. The generic Bessel constant cannot be improved

For alpha_j=<E,psi_j>, the derivative-band output is
sqrt(3)cL sum_{j=0}^5 e_j alpha_(2m-2+j), e=(4,24,53,53,24,4).
The previous weighted Cauchy proof gives squared norm at most
39366 cL^2=2048/243. This constant is sharp: choose alpha_j=1 for
0<=j<=2K+3 and zero elsewhere. For m=1,...,K every output sum equals162;
input squared norm is2K+4. The ratio is at least
3cL^2*162^2*K/(2K+4), tending to39366cL^2.
These alpha are the Laguerre coefficients of a finite smooth exponentially
decaying function, so the obstruction does not require rough or pathological
inputs. Any improvement must exploit the actual arithmetic E, as the
Steklov argument does, rather than improve the unrestricted operator norm.

## 5. Bounded criteria and noncircularity

RH implies nonnegative h_m<=Cxi, so bounded U and eventual negative U follow
from the verified sector identity and independently certified kappa<0.
Conversely a polynomial mean-square bound gives a polynomial pointwise
bound by selecting N=m. Since r is bounded, h has polynomial growth. Its
generating function then has radius at least1; an off-axis zero supplies a
genuine pole of smaller modulus by the already proved denominator and
nonreflection argument. No RH premise entered the auxiliary-sector theorem.
Eventual U<0 supplies a constant lower floor on h, to which the stated
Pringsheim criterion applies. All logical directions are sound.

## 6. Adversarial checks of the new effective candidate

For a decreasing envelope w>=|E| and the right Steklov average E_delta,
the proposed inequalities were reconstructed directly from the variation
measure dV_E. Since
|E(x+t)-E(x)|^2<=2w(x)*V_E((x,x+t]), Fubini proves
||E_delta-E||^2<=delta K0 and integral x|E_delta'|^2<=2K1/delta.
Jensen and right translation give integral x E_delta^2<=integral xE^2.
The Laguerre form eigenvalues3(j+1/2) give exactly the submitted constants.
One must use delta<=1, so the stated simple formula needs J>=1 (or a separate
finite initial case). Jumps are allowed and do not invalidate smoothing.

## 7. Full independent review of the explicit effective tail

Read the complete `effective_sector.md`, not just its theorem statement.
Directly opened Trudgian's author PDF, arXiv:1401.2689v2; Theorem1 on
printed page3 gives precisely the claimed theta bound with R=6.455 and
x>=149. Source toolref turn98view0, lines84--96. The resulting estimate
R(exp(v))/exp(v)<=6exp(-sqrt(v)/(4sqrt2)) was checked separately on
the large-x range and the bounded initial range, using theta<=4x.

Recomputing the integrated error gives 6(65+8sqrt(ell))exp(-sqrt(ell)/8),
and hence the proposed 1024exp(-sqrt(ell)/16) envelope. The integration
constant b=1+integral_1^infinity R(t)/t² dt has the correct sign.
For the shifted envelope, the exact integrals are 525312 and805831168;
P1<=12*1024²*8^4=51539607552. For K1 the derivative estimate gives
integral(4+2u)|g1'|<=8int wshift+6int u wshift; the extra variation du/2
accounts for the coefficient13/2, so K1=5242105088 is correct.

Both Fourier regularization lemmas were rederived. Bounded amplitude and
derivative L1/y² yield approximation error4L0²epsilon and derivative
energy L1²/(3epsilon³). The singular gamma case gives6G0²sqrt(epsilon)
and(2/3)G1²epsilon^-3/2. Their stated factors2 and cosine normalization
1/(8pi) are correct. The gamma differentiated series has integral bound1/t
and twice-maximum bound9/(2sqrt3 t²), so the proposed crude derivative
constant72 is valid. One elementary detail can be made explicit:
y t'/(1+t)<4 follows for t>=a from arctan(a/t)<=a/t, and for t<=a from
max_[0,a](a²+t²)/(1+t)<=a² with a=3/2, giving a*pi/2<4.
Similarly H1<1000 follows from
3/(1-1/sqrt2)²<50 and sum_(n>=2)(log n)²/n^(3/2)<20.

Four-component splitting correctly produces8192/243 in the square sector.
The conservative integer constants give less than2.842e12/sqrt(M) there,
less than1e9/sqrt(M) in Fourier sectors, and less than1e6/sqrt(M) in the
actual moving cutoff. Thus the displayed3e12/sqrt(M) bound has real margin.
The derived weighted summability and O(N^-3/4) complete-sector Cesaro
error follow by dyadic Cauchy--Schwarz, not by a false pointwise inference.
No blocking defect found.

## 8. Independent review of the rotated complete-theta contour

Read all of `theta_candidate.tex` against all relevant bounds and
normalizations in the original `source/saddle.tex`. Reconstructed the
new proof from its two coordinates t_+=D+iy+h_+, t_-=D-iy+h_-.

The exact stationary equations are
n/D-2pi exp(2D) exp(±2iy)±ix=0, because
2pi exp(2D)=n/(DC) and x=n tan(2y)/D. The dominant quadratic is
-n/(DC)[exp(2iy)h_+²+exp(-2iy)h_-²], and the logarithmic quadratic is
-n(h_++h_-)²/(4D²). Along every independent intermediate rotation,
not only the final one, the real source quadratic has loss at least
n(r_+²+r_-²)/D. Its cubic remainder is at most K*rho times that loss
since |h|<=rho*C. The logarithmic quadratic is smaller by1/D.

The strip gap delta=pi/4-y obeys delta>=C/2, since C=sin(2delta)<=2delta.
Every arc stays inside the source strip and obeys
cos(2Im(t_±))>=(1-2rho)C, Re(t_±)>=D-rho. Thus the leading theta mode
and its complete mode remainder are uniformly valid on the WHOLE
deformation. The moment factor is polynomial and imposes no spurious
real-d restriction after the local contour has been isolated.

The full rotation h_+=sqrt2*c*sqrtC*exp(-iy)*a,
h_-=sqrt2*c*sqrtC*exp(iy)*b has Jacobian c²C after the original factor1/2.
Its Gaussian is -(|a|²+|b|²)/2-C(exp(-iy)a+exp(iy)b)²/(8D) for reala,b;
the determinant is1+C²/(2D), on the correct positive branch. Connecting
arcs have areaO(C²); relative to c²C this isO(nC/D), exactly the claimed
exponential prefactor. The new localization outside |h_±|<=rho*C
costs C^-1 exp(-k nC²/D), as asserted.

The complex Taylor inequality is applicable even where imaginary
remainders are large, because BOTH the full and Gaussian exponentials
have a uniform negative-real-quadratic majorant. The odd linear+cubic
polynomial integrates to zero on the symmetric rotated square. Its
remaining integrated error is O(c²C(D²+1)), with D² omitted at zeroheat.
This gives the proposed relative algebraic errorCD³/n and CD/n.

For the final b_n corollary, h_n=min(b_n^-1/2,q_n^-1/2) has h_n→infinity,
h_n q_n→0 and b_n h_n→0 in BOTH branches. Then nC_n²/D grows like
h_n²log n and beats all polynomial prefactors. The Fourier transform
is real because its real kernel is even; together with relativeerroro1
this implies the stated strict positivity. This reality observation
was communicated and added explicitly by the authoring agent.
No blocking defect found; negative fixed heat remains in the quantified
range and therefore still prevents any inference of RH from this wedge.

## 9. Independent review of the cross-degree sampling operator

Read `cross_degree.md` completely. For finite Q=sum u_m H_m, H_m(0)=0
and exponential decay at infinity kill the constant E_D,infinity term
exactly. The synthesis bounds into H1 and L2 for the derivative imply
compactness of multiplication by E_D-E_D,infinity after synthesis:
local compactness is Rellich and the global tail is controlled by the
uniformly vanishing multiplier. Thus the bounded remainder operatorR
is genuinely compact on ordinaryell². The continuous leading operatorJ
is unbounded, so its decomposition should be stated as quadratic forms
on finite sequences, as in the candidate.

Independently checked192 exact rational Laguerre recurrence identities:
m=1,...,24 and k=0,...,7. The mixed coefficient is
a_k(m+(k+1)/2) with a=(8112,-5112,960,128), and vanishes fork>=4.
Also verified exactly21384²=4*2904*39366 and the normalized rowconstant
2*sum_(k=1)^3 |a_k|k²/72=842/3. The normalized arithmetic/geometric
mean error is bounded by k²/[8(M+1/2)²], so the estimate is uniform over
arbitrary block widths and does not hide a fixed-shift assumption.

The actual-cutoff correction has the claimed Hilbert--Schmidt bound:
each column squared norm is at most (K0/3)log(X_m)/sqrt(X_m), from its
OWN scalar prime-tail bound. Dividing by m+1/2 and summing is geometric.
The exact zero-sum condition cancels the common q_infinity term even
with differing cutoffs. The Toeplitz extrema64 and20000 are approached
by long remote zero-sum oscillatory blocks, so the restriction to
zero-sum coefficients does not invalidate sharpness. No blocking defect.

## Bibliographic entry for the Abel proof

    @misc{leong2026,
      author = {Leong, Nicol},
      title = {Explicit estimates for the logarithmic derivative and the
               reciprocal of the {Riemann} zeta function},
      year = {2026},
      eprint = {2405.04869},
      archivePrefix = {arXiv},
      primaryClass = {math.NT},
      note = {Version 5, 30 January 2026},
      url = {https://arxiv.org/abs/2405.04869v5}
    }

Uniformity needed in the Abel proof is exactly Corollary2 for sigma>=1,
t>=13, never the conditional Corollary3. On sigma in[1,3], |t|<=13,
remove the pole at1 and use compactness and the classical zero-free line.

