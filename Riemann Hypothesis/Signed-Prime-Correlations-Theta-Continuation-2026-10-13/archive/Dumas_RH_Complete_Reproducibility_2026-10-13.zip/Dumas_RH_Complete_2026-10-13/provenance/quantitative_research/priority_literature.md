# Focused statement-level prior-art comparison

Research date: 13 October 2026. Scope: the exact arithmetic sector theorem, its bounded and quadratic corollaries, the finite Laguerre stencil, and the closest Weil/operator constructions. This is a focused literature investigation, not evidence of exhaustive worldwide priority coverage. All mathematical comparisons below use primary papers or publisher/author records. No previous Dumas manuscript is proposed as a bibliographical reference.

## Outcome for the principal claim

The inspected antecedents do **not** state the manuscript's exact assertion

\[
\mathcal U_m+h_m=\kappa+r_m,\qquad r\in\ell^2,
\quad X_m=506^{m+2},\quad
\kappa=\Gamma_\infty-S_{\rm pp}[q_\infty]-128/6561.
\]

The strongest defensible distinction is the **specified finite filtered ordinary-prime construction with quantitative removal of the auxiliary sectors**, particularly the nonzero prime-square endpoint and the same moving cutoff. It is not the general ideas of (i) RH criteria from growth, (ii) Laguerre arithmetic representations, (iii) separating archimedean and arithmetic terms, or (iv) using a positive quadratic expression.

The proof's orthogonality and Bessel arguments are classical analytic tools. A precise application can be new without being a new general principle. Likewise the 36 high-band pairings are exact algebra, not on their own a new cancellation theorem. The independently useful analytic statement is the prime-diagonal asymptotic, and the remaining off-diagonal upper bound must remain explicitly unproved.

## 1. Sekatskii: exact predecessor of the Li and Laguerre structure

**Primary sources:**

- S. K. Sekatskii, *Generalized Bombieri–Lagarias' theorem and generalized Li's criterion*, arXiv:1304.7895v3 (7 March 2014), https://arxiv.org/pdf/1304.7895v3. Tool source `turn80view1` / `turn81view2`.
- S. K. Sekatskii, *An arithmetic interpretation of generalized Li's criterion*, arXiv:1305.1421v3 (24 May 2018), https://arxiv.org/pdf/1305.1421v3. Tool source `turn80view0`.

The first paper's **Theorem 2**, printed p.5, equates half-plane location with positivity and with a one-sided bound of the form
\[
\sum_\rho\Re\left[1-\left(\frac{\rho-a}{\rho+a-2\sigma}\right)^n\right]
\ge -c(\epsilon)e^{\epsilon n}\quad(\epsilon>0).
\]
Theorem 3 adds reflection symmetry and gives the corresponding line criterion. Thus the subexponential exclusion principle predates this manuscript. Its proof already uses extremal transformed zeros and simultaneous phase approximation.

The second paper's **Lemma 1**, printed p.3, computes inverse Mellin transforms of the shifted Li test. Printed p.4 identifies the kernel with associated Laguerre polynomials. **Theorem 1, equation (4)**, printed p.5, separates the shifted zero sum into polar, prime-power, digamma and Hurwitz-zeta terms. It uses all von Mangoldt weights. It does not give the present six-band derivative cancellation, the ordinary-prime sector limit, or an \(\ell^2\) remainder at the prescribed cutoff.

**Editorial consequence:** existing attribution to Sekatskii is appropriate; make the theorem/equation pointers explicit. Do not advertise a new generalized Li criterion or a first Laguerre prime representation.

## 2. Lagarias: sector decomposition and spectral interpolation

**Primary source:** J. C. Lagarias, *Li coefficients for automorphic L-functions*, Ann. Inst. Fourier 57 (2007), 1689–1740, DOI 10.5802/aif.2311. Publisher record https://aif.centre-mersenne.org/articles/10.5802/aif.2311/ (`turn82search2`, `turn92search1`); preprint https://arxiv.org/pdf/math/0404394 (`turn84view2`).

Section 4 and **Lemma 4.2** decompose Li coefficients into archimedean and finite-place contributions. **Theorem 5.1** gives the dominant archimedean asymptotic; the introduction and Section 6 distinguish it from exponentially large off-line-zero contributions. **Theorem 7.1** builds exponential-type interpolation; under RH the Fourier support is discrete with one accumulation point. Consequently arithmetic/archimedean separation and pure-frequency interpretations have clear antecedents. The present summable weighted cosine series, conditional covariance formula and explicit filtering are more specialized constructions; they should not be described as the first spectral or Fourier treatment of Li-type data.

## 3. Coffey: signed arithmetic Laguerre sums and degree averaging

**Primary source:** M. W. Coffey, *The Stieltjes constants, their relation to the \(\eta_j\) coefficients, and representation of the Hurwitz zeta function*, Analysis 30 (2010), no.4, 383–409, DOI 10.1524/anly.2010.1048. Full preprint https://arxiv.org/pdf/0706.0343v2 (`turn85view0`, `turn86view1`, `turn87view4`); abstract/history https://arxiv.org/abs/0706.0343 (`turn88view2`). Publisher search metadata `turn84search1` supplies the journal details; direct publisher full-text access failed.

**Proposition 2, equations (15)–(18)**, printed pp.4–5, gives
\[
S_2(n)=S_\gamma(n)+S_\Lambda(n),\qquad
S_\Lambda(n)=\sum_{j\ge1}\frac{1-\Lambda(j)}j
 L_{n-1}^{(1)}(\log j),
\]
and rewrites degree averages using \(L_{M-1}^{(2)}\). Its discussion, printed pp.29–30, isolates sufficient growth control of the arithmetic sum as the missing RH condition. This is a close conceptual antecedent for preserving cancellation in signed Laguerre arithmetic responses. The present sum has a different shift, ordinary-prime support, pole filter, finite moving cutoff and \(\ell^2\) auxiliary error. No such assertion is stated in the inspected proposition.

**Related lead, limited inspection:** Coffey, *The theta-Laguerre calculus formulation of the Li/Keiper constants*, J. Approx. Theory 146 (2007), no.2, 267–275, DOI 10.1016/j.jat.2006.10.006. Publisher metadata/abstract https://www.sciencedirect.com/science/article/pii/S0021904507000044 (`turn90search2`) confirms theta–Laguerre integral reformulations and dominant/subdominant decomposition. Its full text was not accessible in this investigation; do not claim equation-level exclusion of overlap with it. Cite the accessible 2010 paper for the precise comparison above.

## 4. Suzuki: bounded response and norms as RH criteria

**Primary source:** M. Suzuki, *Aspects of the screw function corresponding to the Riemann zeta-function*, J. London Math. Soc. 108 (2023), no.4, 1448–1487, DOI 10.1112/jlms.12785. https://arxiv.org/pdf/2206.03682 (`turn80view2`, `turn81view3`).

**Theorem 1.6** states RH iff the arithmetic screw response \(\Psi(t)\) is bounded on the positive half-line. The converse proof (printed p.25) excludes poles of \(\xi'/\xi\) using analytic continuation of its transform. **Theorem 1.7** gives a pointwise-sign criterion and **Theorem 1.8** a Hankel-moment criterion. Hence boundedness/sign detection is established architecture. The present discrete ordinary-prime sequence and explicit auxiliary-sector limit differ. Its bounded quadratic and polynomial quadratic equivalences follow from this construction and the usual pole-growth mechanism; the equivalences are not independent advances in controlling primes.

**Additional primary source:** Suzuki, *Li coefficients as norms of functions in a model space*, J. Number Theory 252 (2023), 177–194, DOI 10.1016/j.jnt.2023.05.007; https://arxiv.org/pdf/2301.05779v2 (`turn84view0`); journal metadata `turn90search0`.

**Theorem 1.1, equation (1.8)**, printed p.2, states that identities \(\lambda_n=(2\pi)^{-1}\|G_n\|_2^2\) for every \(n\) are equivalent to RH. The functions belong to \(L^2\) unconditionally, while the norm identities are conditional. This is conceptually different from a degree-averaged prime-pair kernel, and it does not imply its missing signed estimate. It is directly relevant when distinguishing a positive norm expression from an independently proved identification with the desired arithmetic quantity.

## 5. Connes–Consani: finite constraints are already permitted

**Primary source:** A. Connes and C. Consani, *Weil positivity and trace formula the archimedean place*, Selecta Math. (N.S.) 27 (2021), article 77, DOI 10.1007/s00029-021-00689-4. Publisher page/full appendices https://link.springer.com/article/10.1007/s00029-021-00689-4 (`turn91view0`); full preprint https://arxiv.org/pdf/2006.13771 (`turn85view1`).

**Appendix C, Proposition 6.12** in the published numbering (Proposition C.1 in the arXiv version) proves Weil's criterion remains equivalent to RH after finitely many Mellin vanishing constraints at points disjoint from the zero set, including 0 and 1. Equations (149)–(154) specify the prime-power and digamma normalization. This is an important missing attribution near the pole-neutral detector. The manuscript's odd real tests, fixed higher pole jets and explicit exponentially negative aperture bound are the refined claims requiring their own proof. Finite neutrality alone is not new. The same paper analyzes an archimedean discrepancy as a scalar part plus compact correction (Theorem 3.6); this is related operator architecture, not the identical physical-prime block.

## 6. Connes–Consani–Moscovici and Suzuki: precise scope of recent operator results

**Primary source:** A. Connes, C. Consani and H. Moscovici, *Zeta Spectral Triples*, arXiv:2511.22755v1 (27 November 2025), https://arxiv.org/pdf/2511.22755 (`turn81view1`, `turn87view0`, `turn87view1`).

**Theorem 5.10**, printed p.23, assumes the lowest finite-dimensional Weil eigenvalue is simple and its eigenvector even. It obtains a self-adjoint perturbed operator, a regularized-determinant identity and real zeros for that eigenvector's Fourier transform. **Section 7** leaves convergence to the Riemann xi function open. Its cutoff \(p\le\lambda^2\) and finite-dimensional parameter are not the present degree-dependent ordinary-prime filter. Neither theorem proves the manuscript's prime-correlation estimate or supersedes its sector theorem; neither may be used as an unconditional global RH anchor.

**Primary source:** Suzuki, *Weil's quadratic form via the screw function*, arXiv:2606.09096v3 (23 September 2026), https://arxiv.org/html/2606.09096v3 (`turn79view3`).

**Theorems 1.1, 1.3, 1.4** give a Friedrichs-extension realization, continuity of the lowest localized eigenvalue, and small-aperture positivity/simplicity/evenness. The source distinguishes these unconditional facts from its limiting spectral conjecture. Section 8.5 retains the interaction between two compact operators in a generalized eigenvalue problem. This supports the manuscript's insistence on controlling the complete coupled form; it does not provide the needed uniform prime estimate.

## Claim classification for the present arithmetic package

| Assertion | Recommended priority description |
|---|---|
| RH from one-sided subexponential or polynomial growth | Established criterion principle; precise filtered specialization here |
| Shifted Li arithmetic Laguerre formula | Established in the cited arithmetic literature |
| Six-band identity and finite-band derivative | Exact identity for the specified filter; useful mechanism, not a new general Laguerre principle |
| Prime-square endpoint \(128/6561\) and \(\ell^2\) complete auxiliary extraction | No exact antecedent found among inspected papers; state the exact theorem, not a universal priority claim |
| Linear prime-diagonal plus constant term | Distinct source-weighted asymptotic in the inspected sources; proof uses classical PNT/orthogonality |
| Double-prime and cross-degree expansion | Exact algebraic construction; significance lies in retaining cancellation and identifying its precise target |
| Bounded/polynomial quadratic and eventual-negativity criteria | Consequences of the exact construction and familiar pole detection; RH-strength estimates remain open |
| Finite pole-neutral Weil constraints | Established antecedent; higher-jet quantitative detector is the potentially distinct refinement |

## Suggested concise manuscript wording

“Generalized Li coefficients already admit arithmetic Laguerre representations, and signed Laguerre sums and their degree averages were studied by Coffey. The contribution here is the specified pole-neutral finite ordinary-prime filter together with complete removal of the auxiliary sectors: the prime-square boundary term is retained and the remaining deviations are square summable. Bounded-response criteria themselves have antecedents in Suzuki's screw-function criterion; their role here is to identify the growth scale required of this explicit prime sequence.”

Near the detector: “Weil positivity remains an RH criterion under finitely many Mellin vanishing constraints, as shown by Connes–Consani following Yoshida. The theorem below retains fixed pole jets and gives an explicit negative exponential rate in the aperture.”

## Search and evidence limits

Both search engines were used for combinations of Li/generalized Li, Laguerre, finite differences, signed arithmetic sums, square summability, prime squares, Bessel inequalities, bounded response and the named authors. Exact phrase searches often returned sparse or irrelevant results. Their failure is not evidence of priority. The sources above were selected because their actual formulas overlap the relevant constructions. This investigation does not establish first discovery of every claim in the 92-page paper, and it does not independently referee the external papers. The uninspected full text of Coffey's 2007 article is an explicit remaining prior-art limitation.

Tool references in this working note are retrieval identifiers, not proposed bibliography text. The root agent must open relevant URLs before using web citations in a user-facing answer.
