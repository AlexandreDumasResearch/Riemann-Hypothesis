# Fresh complete-theta quadrature: mathematical certificate

The file `code/fresh_source.py` reconstructs, without prior moments or zeros,

\[
I_k=\int_0^\infty u^{2k}\Phi(u)\,du,\qquad
\Phi(u)=e^{u/2}\sum_{j\ge1}(8X_j^2-12X_j)e^{-X_j},\quad
X_j=\pi j^2e^{2u},\quad0\le k\le88.
\]

The supplied implementation uses python-flint's Arb real balls at 850 bits.
It implements the following analytic error estimates. No prior moment enclosure is used when reconstructing the enclosures. The integrated release retains the previously validated inputs; its finite-check replay does not rerun this quadrature unless `--rebuild-source` is requested.

## Gaussian nodes and weights

Divide [0,4] into 32 equal cells with half-width h=1/16. On each cell use the
120-point Gauss–Legendre rule. Approximate Legendre roots are proposed using
mpmath Newton iteration; they are never accepted as exact roots. Each proposed
root receives rational endpoints of width 2×10^-160. Arb proves opposite
strict signs at the endpoints, verifies all 120 brackets are disjoint and in
(-1,1), and encloses the weights

\[
w_i=\frac{2}{(1-z_i^2)P'_{120}(z_i)^2}>0.
\]

The degree count exhausts all roots. The standard Gaussian quadrature theorem
then supplies exactness through degree 239 and total weight two. This theorem
follows by dividing a polynomial of degree at most 239 by P_120 and using
Legendre orthogonality for the quotient, followed by Lagrange interpolation
of the remainder. Positivity follows by applying exactness to squared
Lagrange basis functions. The implementation additionally checks the interval
sum of weights contains two.

## Complete mode tails

At a real nonnegative argument put X=π exp(2u), M=8, j0=9, and

\[
r=\left(\frac{j_0+1}{j_0}\right)^4e^{-(2j_0+1)X}.
\]

The ratio of consecutive positive majorant terms decreases for j≥j0. The full
omitted mode tail is therefore bounded by

\[
e^{u/2}\frac{(8j_0^4X^2+12j_0^2X)e^{-j_0^2X}}{1-r}.
\]

The code checks r<1 and adds a symmetric ball of this radius. All mode tails
are included at every quadrature point.

## Analytic quadrature error

For a disk |z-c|≤R=1/4, set A_c=π exp(2(c+R)) and
b_c=π exp(2(c-R)) cos(2R)>0. A bound for the complete source is

\[
B_c=e^{(c+R)/2}\left[
\sum_{j=1}^{8}(8A_c^2j^4+12A_cj^2)e^{-b_cj^2}
+\frac{(8A_c^2 9^4+12A_c9^2)e^{-81b_c}}
 {1-(10/9)^4e^{-19b_c}}\right].
\]

Arb checks the positive denominators. Gaussian decay proves locally uniform
convergence and analyticity on these disks. Hence the full moment integrand
has modulus at most M_ck=(c+R)^(2k) B_c. Cauchy's Taylor remainder through
degree 239 is bounded by M_ck(h/R)^240/(1-h/R). Both exact integration and
Gaussian quadrature have positive mass 2h, so their difference is bounded by

\[
E_{c,k}=4h(c+R)^{2k}B_c\frac{(h/R)^{240}}{1-h/R}.
\]

The code sums this bound over every cell and adds the resulting ball.

## Complete spatial tail

For u≥4 let A=πe^8. The ratio of consecutive j^4 exp[-(j²−1)X] terms is at
most 16 exp(-3A)<1/2. Thus 0<Φ(u)≤40 exp(u/2)X²exp(-X). The logarithmic
slope of u^(2k)exp(u/2)X²exp(-X) is at most -λ_k, where
λ_k=2A-9/2-k/2>0. Consequently

\[
0<\int_4^\infty u^{2k}\Phi(u)\,du
\le\frac{40\,16^k e^2A^2e^{-A}}{2A-9/2-k/2}.
\]

The implementation verifies λ_k>0 for every computed k and adds a conservative
symmetric enlargement covering this tail.

## Serialization and remaining trust

Arb's exact lower/upper dyadic bounds are serialized as signed mantissa and
binary exponent; displayed decimals are not proof inputs. The algebraic
checker reads these endpoints into rational intervals. The finite certificate
relies on the stated analytic estimates, Gaussian exactness, correct execution
of Arb's outward enclosures, and the checker implementation. It is not a
proof-assistant formalization. The finite inequalities do not imply an
unbounded-order bound or the Riemann hypothesis.

## Second reconstruction

Run `python code/fresh_source.py --cross-check` after the baseline. It uses
48 cells, 128 nodes per cell, 10 explicit modes, 1000 bits, and node brackets
of radius 1e-200. The same bounds apply with h=1/24, j0=11 and Taylor exponent
256. Every moment is constructed anew before comparing exact endpoints;
all 89 cross-check intervals are contained in the baseline intervals. The
maximum relative width is less than 2.644e-152. This is a second parameter
configuration, sharing the analytic method and Arb library, not an independent
formalization. The baseline inputs remain those used by the sign checker.
