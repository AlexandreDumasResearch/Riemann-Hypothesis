SIGNED PRIME CORRELATIONS AND THETA CONTINUATION FOR THE RIEMANN XI FUNCTION
Effective sector remainders, signed arithmetic criteria, and complete-source positivity
Complete research manuscript and reproducibility companion
Alexandre Dumas | Independent researcher | ORCID 0009-0003-1695-0086
13 October 2026

CONTENTS

The PDF is a standalone mathematical research article. source/ contains the
complete LaTeX manuscript and bibliography; figures/ contains vector figures
and PNG previews. code/ contains the complete source integrator, outward
rational-interval arithmetic, exact checks, certificate scripts and figure
scripts. inputs/ contains 89 validated complete-theta moment enclosures and
an independent-parameter reconstruction. results/ contains actual outputs,
exact rational endpoints, a CSV table and replay records. QUADRATURE.md
specifies the analytic quadrature, omitted-mode and spatial-tail bounds.
provenance/ distinguishes inherited source-integration records from the
finite checks rerun for this integrated release.

QUANTITATIVE RESULTS IN THIS RELEASE

The complete manuscript contains effective tail energy
  sum_{m>=M}|r_m|^2 <= 3*10^12/sqrt(M), M>=2,
a pointwise O(m^(-3/4)*log(m+2)^(5/2)) rate, weak-l^(4/3)
regularity, an exact complete-sector Parseval identity, the cross-degree
Jacobi-plus-compact theorem and its sharp symbol range [64,20000], and
opposite-contour theta positivity on b_n*n^(3/2)/(log n)^2 for b_n -> 0.
The large explicit tail constant is conservative, not a practical onset.
The prime sampling bound is relative to the weighted coefficient norm;
broad averaging may shrink that norm. The signed distinct-prime bound
remains unproved. No exact optimality of the remainder rate is claimed.

To replay only the new computations:

    .venv/bin/python code/run_quantitative_checks.py

This run was completed and is recorded in results/quantitative_replay.json.
The four new scripts check 1121 exact cross-degree assertions, 37 exact
sector constants/form identities, the pointwise differential-equation and
band algebra, and 15 exact rotated-saddle identities. Floating adjacent-
Laguerre samples are labeled diagnostics. The actual infinite-dimensional
and contour estimates are proved analytically in the manuscript.
The prior complete finite replay is preserved in results/integrated_replay.json;
it was not rerun in full merely to duplicate unchanged calculations.

MATHEMATICAL SCOPE

The paper proves an unconditional square-summable remainder identity for the
prescribed finite ordinary-prime sums, an exact linear prime-diagonal energy
asymptotic and source-preserving obstruction results. Boundedness, bounded
quadratic averages and eventual negativity of the complete prime sums are
RH-equivalent conclusions, not established bounds. The signed ordinary-prime
correlation estimate and the all-degree actual Jensen residue signs remain
unresolved. The paper also preserves the established elementary finite-prime
criterion, divisor surplus, discriminant/heat, continuation, saddle and
operator/packet/source-perturbation results.

Finite exact checks support the written identities. They do not prove their
all-degree analytic extensions. The actual-source covariance countertest is
not an actual Laguerre predecessor-root test. Packet countermodels use the
actual arithmetic stencil but are adversarial measures, not actual-prime
counterexamples. Source perturbations change the complete integer Gaussian
series. Numerical diagnostics are explicitly separated from certificates.
No proof-assistant formal verification or worldwide novelty guarantee is
claimed. RH remains unresolved.

VERIFY THE SUPPLIED SNAPSHOT

Before regenerating outputs, run from this directory:

    python3 code/verify_manifest.py

or, on a system providing the utility:

    sha256sum -c SHA256SUMS.txt

The manifest covers all delivered files except itself. Reproduction changes
runtime fields and figure PDF timestamps. Arithmetic-library changes can
also alter valid endpoint representations. Compare mathematical assertions
and exact inclusions, rather than expecting regenerated file hashes to match.

REPLAY THE FINITE CHECKS

Tested with Python 3.12 and the packages recorded in
results/integrated_replay.json and results/quantitative_replay.json. Create a virtual environment and install:

    python3 -m venv .venv
    .venv/bin/python -m pip install -r requirements.txt
    .venv/bin/python code/run_checks.py --diagnostics --figures

On Windows use the corresponding .venv/Scripts/python executable.
Do not use Python's -O option: the checks use assertions.
Scripts resolve data paths relative to their own location and can be run
from another working directory using their absolute paths.

The default run reuses the supplied validated moment input. It performs the following inherited checks and the four new checks described above:

  check.py
    Exact algebra, fifteen theta-diagonal interval certificates and an
    independently summed infinite ordinary-prime sign with full tail.
  check_structures.py, check_constants.py, check_quarter.py
    Finite exact discriminant/heat/commutator identities, primitive-window
    checks, 4,095 divisor responses and ten complete-graph identities.
  check_arithmetic_independent_v2.py, check_scalar_tail_v2.py,
  check_heat_v2.py, check_appendix_v2.py
    Further finite exact arithmetic, scalar-tail, heat and appendix checks.
    Historical suffixes identify stable executable files, not paper titles.
    Any floating diagnostics inside an output remain labeled as such.
  quadratic_checks.py
    464 exact finite Laguerre-band, energy, kernel and constant checks.
  check_theta_covariance_obstruction.py
    Exact interval propagation from source moments and a symbolic quartic
    witness for failure of a universal centered-test covariance sign rule.
  certify_sector_constant.py
    Fresh dyadic-log ordinary-prime sum through 65,536, the full omitted-prime
    tail and exact interval propagation from the validated source moments.
  certify_sector_sign.py
    Independent Arb Taylor arithmetic for xi at s=2, ordinary primes through
    10,000 and the full tail; this proves -7/50 < kappa < -2/25.
  check_residue_replacement.py, check_scouting_models.py
    Rational replacement identities and exact lobe/curvature countermodels.

The --diagnostics option additionally runs saddle_v2_replay.py,
check_packet_stencil.py and prime_sector_constants.py. Saddle ratios and
high-precision decimal estimates in these files are not validated interval
certificates or proof inputs. The packet script also performs exact finite
moment-cancellation checks; its output distinguishes the two kinds.
The --figures option regenerates both figures and results/diagonal_table.csv.
Kernel curves are illustrative floating-point evaluations. The certificate
plot reads the supplied or regenerated validated rational endpoints.

REBUILD THE SOURCE MOMENTS

The source quadrature was not rerun during this integration. The original
89 complete-source enclosures are byte-identical to the supplied earlier
validated input, with SHA-256:

  8f2ec4a44b13db3a0a35afa8f390ff5b0598820d8e05ac6be751be14cb71f31b

No xi zero lists or historical numerical moment tables were inputs to that
source reconstruction. To regenerate both moment integrations and then the
finite checks, run:

    .venv/bin/python code/run_checks.py --rebuild-source --diagnostics --figures

For source-only reconstruction the commands are:

    .venv/bin/python code/fresh_source.py
    .venv/bin/python code/fresh_source.py --cross-check

The second run changes the cells, quadrature order, number of explicit modes
and precision, and verifies all 89 interval intersections. Both use the same
stated analytic enclosure method and Arb library. Their full error treatment
is documented in QUADRATURE.md and the manuscript's numerical appendix.
provenance/inherited_integration_records/ retains the original integration
logs independently of later regenerated results. The saved input is used
only where its exact enclosures are justified; its provenance is not a claim
that a source integration was executed again during this release.

BUILD THE COMPLETE PAPER

A standard TeX Live installation with latexmk, pdfLaTeX, BibTeX, Latin Modern,
AMS packages, natbib, microtype, graphicx and hyperref is sufficient.
From source/ run:

    latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex

The output is source/main.pdf. Figure PDFs are already supplied; a LaTeX build
does not require rerunning Python. The source contains the complete proofs,
cross-references, bibliography and author's ORCID.

PUBLICATION

The supplied Zenodo metadata, description and citation file are editable
submission materials. No DOI has been invented or reserved. Choose license
and access settings at deposit, and add the issued DOI to the record and
CITATION.cff afterward. These files do not create or publish a Zenodo record.
