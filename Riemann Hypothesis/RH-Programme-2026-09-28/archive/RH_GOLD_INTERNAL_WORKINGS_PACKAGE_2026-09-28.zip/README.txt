RH GOLD INTERNAL WORKINGS PACKAGE - 28 September 2026

Contents
--------
1. RH_GOLD_INTERNAL_WORKINGS_BOOK_2026-09-28.pdf
   Navigable reading edition: current frontier, chronology, audit corrections,
   high-value recovered equations, failed-route firewall, and restart protocol.

2. RH_GOLD_INTERNAL_WORKINGS_BOOK_2026-09-28.md
   Exhaustive searchable archive. This is the primary long-term research object.
   It contains 817,000+ lines of recovered/consolidated RH material.

3. SHA256SUMS.txt
   Cryptographic hashes for integrity checking.

Status boundary
---------------
RH_PROVED=false at this freeze. Historical proof-candidate, PASS, ACTIVE, or
working-TRUE labels are retained as provenance and must be read through later
hostile-audit/supersession records.

Source-vault note
-----------------
The original recovered binary research vault is about 1.5 GB and is intentionally
kept split into its historical archive parts rather than recompressed into one giant
file. This package therefore remains practical to download while the Markdown
preserves the integrated research record.
